﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using PMS.Core;

namespace PMS.Service
{
    [ServiceContract]
    public interface IPMService
    {
        [WebGet(UriTemplate = "/Start/{machines}/{monitoringType}/{runId}")]
        [OperationContract]
        Task[] CreateCounterAndWorkOnMachine(string machines, string monitoringType, string runId);

        [WebGet(UriTemplate = "/GetCounters/{machine}")]
        [OperationContract]
        Task[] GetCountersOnMachine(string machine);

        [WebGet(UriTemplate = "/End/{runId}")]
        [OperationContract]
        Task[] StopCounters(string runId);

        [WebGet(UriTemplate = "/HeartBeat/{runId}")]
        [OperationContract]
        int HeartBeat(string runId);
    }
}
