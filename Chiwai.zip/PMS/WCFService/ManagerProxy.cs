﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PMS.Core;

namespace PMS.Service
{
    public class ManagerProxy
    {
       #region Singleton
        private static volatile ManagerProxy instance;
        private static object syncRoot = new Object();
        public static ManagerProxy Instance
        {
            get
            {
                /// Double-Check Locking 
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                        {
                            instance = new ManagerProxy();
                        }
                    }
                }
                return instance;
            }
        }

        protected ManagerProxy(PerformanceMonitorConfig config)
        {
            //PerformanceMonitorConfig c = new PerformanceMonitorConfig()
            //{
            //    BasicCounters = new List<CounterConfig>(),
            //    AdvancedCounters = new List<CounterConfig>(),
            //    Machines = new List<MachineEntry>(),
            //    KeepAlive = 90,
            //    LogFetchedValues=true,
            //    LogDbConnectionString = "Data Source=chellsbanl01;Initial Catalog=SledgeHammerData;Persist Security Info=True;User ID=SledgeDbDat;Password=SledgeDbDatPw"
            //};

            //c.Machines.Add(new MachineEntry() { MachineName = "EsfVMVI-926", MonitoringType = MonitoringTypes.Basic });
            //c.BasicCounters.Add(new PerfMonCounterConfig()
            //{
            //    Id = 1,
            //    FriendlyName = "CPU Usage",
            //    Interval = 2,
            //    IsEnabled = true,
            //    IsInteger = false,
            //    Category = "Processor",
            //    Name = "% Processor Time",
            //    Instance = "_Total"
            //});
            //c.BasicCounters.Add(new PerfMonCounterConfig()
            //{
            //    Id = 2,
            //    FriendlyName = "Memeory Pages/sec",
            //    Interval = 2,
            //    IsEnabled = true,
            //    IsInteger = false,
            //    Category = "Memory",
            //    Name = "Pages/sec",
            //    Instance = null
            //});
            //c.BasicCounters.Add(new PerfMonCounterConfig()
            //{
            //    Id = 3,
            //    FriendlyName = "PhysicalDisk Avg. Disk Queue Length",
            //    Interval = 2,
            //    IsEnabled = true,
            //    IsInteger = false,
            //    Category = "PhysicalDisk",
            //    Name = "Avg. Disk Queue Length",
            //    Instance = string.Empty
            //});
            //c.BasicCounters.Add(new PerfMonCounterConfig()
            //{
            //    Id = 4,
            //    FriendlyName = "Sandboxlib PageManager Free Pages",
            //    Interval = 2,
            //    IsEnabled = true,
            //    IsInteger = true,
            //    Category = "Sandboxlib: General Counters",
            //    Name = "PageManager Free Pages",
            //    Instance = string.Empty
            //});


            //c.AdvancedCounters.Add(new EventLogCounterConfig()
            //{
            //    Id = 101,
            //    FriendlyName = "Error Count by EvnetCode",
            //    Interval = 300,
            //    IsEnabled = true,
            //    IsInteger = false,
            //    DeferringStart = 300,
            //    DeferringEnd = 300,
            //    LogName = "Application",
            //    EntryType = EventLogEntryTypes.Error,
            //    Source = string.Empty,
            //    Categroy = string.Empty,
            //    EventCode = null,
            //    FilterType = EventLogEntryFilterTypes.None,
            //    FilteredBy = string.Empty,
            //    GroupType = EventLogEntryAggregationTypes.Count,
            //    GroupBy = "EventCode",
            //    TimeScale = 30,
            //    UseGroupValueToFormFriendlyName = true
            //});

            //c.AdvancedCounters.Add(new EventLogCounterConfig()
            //{
            //    Id = 102,
            //    FriendlyName = "LodgingPerfMetrics M1802",
            //    Interval = 300,
            //    IsEnabled = true,
            //    IsInteger = false,
            //    DeferringStart = 300,
            //    DeferringEnd = 300,
            //    LogName = "perfmon",
            //    EntryType = EventLogEntryTypes.Error,
            //    Source = "WinEventLog:LodgingPerfMetrics",
            //    Categroy = string.Empty,
            //    EventCode = 18,
            //    FilterType = EventLogEntryFilterTypes.FromDescription,
            //    FilteredBy = @"M1802\s*=\s*\d+",
            //    GroupType = EventLogEntryAggregationTypes.Avg,
            //    GroupBy = @"(M1802\s*=\s*\?<GroupBy>d+)",
            //    TimeScale = 30,
            //    UseGroupValueToFormFriendlyName = false
            //});

            //string s = Helper.DataContractSerialize(c);
            //using (System.IO.FileStream fs = new System.IO.FileStream(@"F:\VS Projects\PMS\WCFService\bin\Config1.xml", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.Write))
            //{
            //    fs.Seek(0, System.IO.SeekOrigin.Begin);
            //    using (System.IO.StreamWriter writer = new System.IO.StreamWriter(fs, System.Text.Encoding.UTF8))
            //    {
            //        writer.Write(s);
            //    }
            //}
            this.Manager = new Manager(config);
        }

        protected ManagerProxy() :
            this(Helper.DataContractDeserialize<PerformanceMonitorConfig>(
                            Helper.LoadTextFile(System.IO.Path.Combine(Helper.ExecutingDirectory, "Config.xml"))))
        {

        }
        #endregion

        public Manager Manager{get; private set;}


    }
}