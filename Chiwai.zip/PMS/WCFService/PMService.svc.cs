﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using PMS.Core;
using System.Threading;

namespace PMS.Service
{
    public class PMService : IPMService
    {
        public Task[] CreateCounterAndWorkOnMachine(string machines, string monitoringType, string runId)
        {
            if (string.IsNullOrEmpty(machines))
            {
                return new Task[0];
            }
            MonitoringType type;
            if (!Enum.TryParse(monitoringType, true, out type))
            {
                return new Task[0];
            }
            long id;
            if (!long.TryParse(runId, out id))
            {
                return new Task[0] ;
            }

            List<Task> taskList = new List<Task>();
            string[] machineList = machines.Split(',');
            foreach (string machine in machineList)
            {
                taskList.AddRange(ManagerProxy.Instance.Manager.CreateCounterAndWorkOnMachine(machine, type, id, string.Empty));
            }

            Task[] tasks = taskList.ToArray();
            int retriedCount = 0;
            while (retriedCount < 40 && tasks.Any(t => t.Status == TaskStatus.NotCreated))
            {
                if (retriedCount < 10)
                {
                    Thread.Sleep(500);
                }
                else if (retriedCount < 20)
                {
                    Thread.Sleep(1000);
                }
                else if (retriedCount < 30)
                {
                    Thread.Sleep(3000);
                }
                else
                {
                    Thread.Sleep(5000);
                }
                retriedCount++;
                //tasks = ManagerProxy.Instance.Manager.GetTasksOnMachine(machine, type);
            }
            return tasks;
        }

        public Task[] GetCountersOnMachine(string machine)
        {
            return ManagerProxy.Instance.Manager.GetTasksOnMachine(machine);
        }

        public Task[] StopCounters(string runId)
        {
            long id;
            if (!long.TryParse(runId, out id))
            {
                return new Task[0];
            }
            return ManagerProxy.Instance.Manager.StopTasks(id, string.Empty);
        }

        public int HeartBeat(string runId)
        {
            long id;
            if (!long.TryParse(runId, out id))
            {
                return -1;
            }
            return ManagerProxy.Instance.Manager.HeartBeat(id);
        }
    }
}
