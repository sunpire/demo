﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using PMS.Core;

namespace PMS.Service
{
    public class PMAdminService : IPMAdminService
    {
        public List<Task> CreateCounters()
        {
            return ManagerProxy.Instance.Manager.CreateAllTasks();
        }

        public Task[] CreateCountersOnMachine(string machine, string monitoringType)
        {
            if (string.IsNullOrEmpty(machine))
            {
                //return "Please specify the Machine name";
                return new Task[0];
            }
            MonitoringType type;
            if (!Enum.TryParse(monitoringType, true, out type))
            {
                return new Task[0];
            }
            return ManagerProxy.Instance.Manager.CreateTasksOnMachine(machine, type);
        }

        public Task[] WorkOnMachine(string machine, string monitoringType, string runId, string interval)
        {
            if (string.IsNullOrEmpty(machine))
            {
                //return "Please specify the Machine name";
                return new Task[0];
            }
            MonitoringType type;
            if (!Enum.TryParse(monitoringType, true, out type))
            {
                return new Task[0];
            }
            long id;
            if (!long.TryParse(runId, out id))
            {
                return new Task[0];
            }
            return ManagerProxy.Instance.Manager.WorkOnMachine(machine, type, id, interval);
        }

        public Task[] CreateCounterAndWorkOnMachine(string machines, string monitoringType, string runId, string interval)
        {
            if (string.IsNullOrEmpty(machines))
            {
                //return "Please specify the Machine name";
                return new Task[0];
            }

            string[] machineList = machines.Split(',');
            MonitoringType type;
            if (!Enum.TryParse(monitoringType, true, out type))
            {
                return new Task[0];
            }
            long id;
            if (!long.TryParse(runId, out id))
            {
                return new Task[0] ;
            }

            List<Task> t = new List<Task>();
            foreach (string machine in machineList)
            {
                t.AddRange(ManagerProxy.Instance.Manager.CreateCounterAndWorkOnMachine(machine, type, id, interval));
            }

            return t.ToArray();
        }


        public Task[] GetCountersOnMachine(string machine)
        {
            return ManagerProxy.Instance.Manager.GetTasksOnMachine(machine);
        }

        public Task[] GetAllRunningCounters(string monitoringType)
        {
            MonitoringType type;
            if (!Enum.TryParse(monitoringType, true, out type))
            {
                return new Task[0];
            }
            return ManagerProxy.Instance.Manager.GetAllRunningCounters(type);
        }

        public List<Task> GetAllCounters()
        {
            return ManagerProxy.Instance.Manager.GetAllTasks();
        }

        public Task[] StopCounters(string runId, string interval)
        {
            long id;
            if (!long.TryParse(runId, out id))
            {
                return new Task[0];
            }
            return ManagerProxy.Instance.Manager.StopTasks(id, interval);
        }

        public List<Task> StopAllCounters(string interval)
        {
            ManagerProxy.Instance.Manager.StopAllTasks(interval);
            return ManagerProxy.Instance.Manager.GetAllTasks();
        }

        public Task[] KillCountersOnMachine(string machine)
        {
            ManagerProxy.Instance.Manager.KillTasksOnMachine(machine);
            return ManagerProxy.Instance.Manager.GetTasksOnMachine(machine);
        }

        public List<Task> KillAllCounters()
        {
            ManagerProxy.Instance.Manager.KillAllTasks();
            return ManagerProxy.Instance.Manager.GetAllTasks();
        }

        public int HeartBeat(string runId)
        {
            long id;
            if (!long.TryParse(runId, out id))
            {
                return -1;
            }
            return ManagerProxy.Instance.Manager.HeartBeat(id);
        }

        //public Task SetInterval(string category, string counter, string instance, string machine, string monitoringType, string interval)
        //{
        //    ManagerProxy.Instance.Manager.SetInterval();
        //}


        //public List<DataItem> GetCounterBufferedValues(string category, string counter, string instance, string machine)
        //{
        //}


    }
}
