﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using PMS.Core;

namespace PMS.Service
{
    [ServiceContract]
    public interface IPMAdminService
    {
        [WebGet(UriTemplate = "/CreateAll")]
        [OperationContract]
        List<Task> CreateCounters();

        [WebGet(UriTemplate = "/Create/{machine}/{monitoringType}")]
        [OperationContract]
        Task[] CreateCountersOnMachine(string machine, string monitoringType);

        [WebGet(UriTemplate = "/Work/{machine}/{monitoringType}/{runId}?interval={interval}")]
        [OperationContract]
        Task[] WorkOnMachine(string machine, string monitoringType, string runId, string interval);

        [WebGet(UriTemplate = "/CreateAndWork/{machines}/{monitoringType}/{runId}?interval={interval}")]
        [OperationContract]
        Task[] CreateCounterAndWorkOnMachine(string machines, string monitoringType, string runId, string interval);

        [WebGet(UriTemplate = "/Get/{machine}")]
        [OperationContract]
        Task[] GetCountersOnMachine(string machine);

        [WebGet(UriTemplate = "/GetAllRunning/{monitoringType}")]
        [OperationContract]
        Task[] GetAllRunningCounters(string monitoringType);

        [WebGet(UriTemplate = "/GetAll")]
        [OperationContract]
        List<Task> GetAllCounters();

        [WebGet(UriTemplate = "/End/{runId}?interval={interval}")]
        [OperationContract]
        Task[] StopCounters(string runId, string interval);

        [WebGet(UriTemplate = "/EndAll?interval={interval}")]
        [OperationContract]
        List<Task> StopAllCounters(string interval);

        [WebGet(UriTemplate = "/Kill/{machine}")]
        [OperationContract]
        Task[] KillCountersOnMachine(string machine);

        [WebGet(UriTemplate = "/KillAll")]
        [OperationContract]
        List<Task> KillAllCounters();

        [WebGet(UriTemplate = "/HeartBeat/{runId}")]
        [OperationContract]
        int HeartBeat(string runId);
        
        //[WebGet(UriTemplate = "/SetInterval/{category}/{machine}?counter={counter}&instance={instance}&interval={interval}")]
        //[OperationContract]
        //Task SetInterval(string category, string counter, string instance, string machine, string monitoringType, string interval);

        //[WebGet(UriTemplate = "/CreateWorkAll")]
        //[OperationContract]
        //List<Task> CreateCountersAndWork();

        //[WebGet(UriTemplate = "/GetBuffer/{category}/{machine}?counter={counter}&instance={instance}")]
        //[OperationContract]
        //List<DataItem> GetCounterBufferedValues(string category, string counter, string instance, string machine);

    }
}
