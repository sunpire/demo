﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;
using PMS.Service;

namespace PMS.WindowsServiceHost
{
    public partial class PMWindowService : ServiceBase
    {
        private ServiceHost host, hostAdmin;
        public PMWindowService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                host = new ServiceHost(typeof(PMService));
                host.Open();
                PMS.Core.Logger.Instance.Log("WCF RESTFul Service started");

                hostAdmin = new ServiceHost(typeof(PMAdminService));
                hostAdmin.Open();
                PMS.Core.Logger.Instance.Log("WCF RESTFul Admin Service started");
            }
            catch (Exception ex)
            {
                PMS.Core.Logger.Instance.Log(ex, "Failed to start service");
            }
        }

        protected override void OnStop()
        {
            try
            {
                ManagerProxy.Instance.Manager.ShutDown();
                host.Close();
                hostAdmin.Close();
                PMS.Core.Logger.Instance.Log("WCF RESTFul Service closed");
                PMS.Core.Logger.Instance.Log("WCF RESTFul Admin Service closed");
            }
            catch (Exception ex)
            {
                PMS.Core.Logger.Instance.Log(ex, "Failed to stop service");
            }
        }
    }
}
