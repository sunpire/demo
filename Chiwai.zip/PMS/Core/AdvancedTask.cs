﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Diagnostics;
using System.Threading;

namespace PMS.Core
{
    /// <summary>
    /// It is composited of RunId, RequestStart, RequestEnd.
    /// It is used in the deferring Start/End scenarios, we need to save all the deferring requests.
    /// </summary>
    public class AdvancedTaskRequest
    {
        internal long RunId { get; private set; }
        internal DateTime Start { get; private set; }
        internal DateTime End { get; set; }

        internal AdvancedTaskRequest(long runId, DateTime start, DateTime end)
        {
            this.RunId = runId;
            this.Start = start;
            this.End = end;            
        }
    }

    [DataContract]
    public abstract class AdvancedTask : Task
    {
        public bool IsIdle
        {
            get { return this.requestedRunIds.Count == 0 && this.queryingRunIds.Count == 0; }
        }

        protected static object syncRoot = new Object();

        /// <summary>
        /// A RunId enqueques requests into this queue when
        ///     1. At the first time.
        ///     2. After performing the query.
        ///     3. Asked to be completed.
        ///     
        /// A RunId dequeques requests from this queue when
        ///     1. starting to perform the query.
        /// </summary>
        protected Queue<AdvancedTaskRequest> requestedRunIds;

        /// <summary>
        /// Every time it performs a query, the query result can be related to more than 1 RunIds,
        /// so that we need a List<> to store the requests dequequed from 'requestedRunIds' 
        /// </summary>
        protected List<AdvancedTaskRequest> queryingRunIds;
        
        /// <summary>
        /// The last enquequed Request Tuple
        /// </summary>
        protected AdvancedTaskRequest lastRequest;

        /// <summary>
        /// The last dequeued Request Tuple
        /// </summary>
        protected AdvancedTaskRequest lastRequestDequeued;

        protected DateTime CalibrateToTargetMachineTime(DateTime dt)
        {
            return dt + WmiHelper.GetRemoteMachineTimeDiff(this.Instance.Machine);
        }

        protected void EnqueueRequest(long runId, DateTime start, DateTime end)
        {
            this.lastRequest = new AdvancedTaskRequest(runId, this.CalibrateToTargetMachineTime(start), this.CalibrateToTargetMachineTime(end));
            lock (syncRoot)
            {
                this.requestedRunIds.Enqueue(this.lastRequest);
            }
        }

        /// <summary>
        /// Enqueue a new request or update the last enqueued request
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="secondsTimespan"></param>
        protected void EnqueueNextRequest(long runId, int secondsTimespan)
        {
            if (this.requestedRunIds.Count == 0)
            {
                this.EnqueueRequest(runId, this.lastRequest.Start.AddSeconds(secondsTimespan), this.lastRequest.End.AddSeconds(secondsTimespan));
            }
            else
            {
                if (this.lastRequest.RunId == runId)
                {
                    this.lastRequest.End = this.lastRequest.End.AddSeconds(secondsTimespan);
                }
            }
        }

        protected AdvancedTaskRequest DequeueRequest()
        {
            if (this.requestedRunIds.Count > 0)
            {
                this.lastRequestDequeued = this.requestedRunIds.Dequeue();
            }
            else
            {
                this.lastRequestDequeued = null;
            }
            return this.lastRequestDequeued;
        }

        protected int DequeueAllRequestes()
        {
            lock (syncRoot)
            {
                int count = 0;
                while (this.requestedRunIds.Count > 0)
                {
                    this.DequeueRequest();
                    if (this.lastRequestDequeued != null)
                    {
                        this.queryingRunIds.Add(this.lastRequestDequeued);
                        count++;
                    }
                }
                return count;
            }
        }

        /// <summary>
        /// Update the End of the last request in this.requestedRunIds.
        /// If the last request is been handling, it enqueues a new request
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="newEnd"></param>
        protected void UpdateLastRequest(long runId, DateTime newEnd, int secondsTimespan)
        {
            if (this.lastRequestDequeued == this.lastRequest)
            {
                this.EnqueueNextRequest(runId, secondsTimespan);
            }
            if (this.lastRequest.RunId == runId)
            {
                this.lastRequest.End = this.CalibrateToTargetMachineTime(newEnd);
            }
        }
    }

    [DataContract]
    public class EventLogTask : AdvancedTask
    {
        private BaseEventLogBehavior behavior;
        
        private EventLogCounter TheEventLogCounter
        {
            get
            {
                return (EventLogCounter)this.Instance.TheCounter;
            }
        }

        public EventLogTask(string machine, EventLogCounter counter, int interval)
        {
            this.Instance = new CounterInstance(machine, counter);
            this.Interval = interval;
            this.requestedRunIds = new Queue<AdvancedTaskRequest>();
            this.queryingRunIds = new List<AdvancedTaskRequest>();
            if (!counter.DeferringStart.HasValue) // || counter.DeferringStart.HasValue && counter.DeferringStart.Value != interval)
            {
                counter.DeferringStart = interval;
            }
            if (!counter.DeferringEnd.HasValue || counter.DeferringEnd.HasValue && counter.DeferringEnd.Value != interval)
            {
                counter.DeferringEnd = interval;
            }

            this.behavior = EventLogBehaviorFactory.CreateEventLogBehavior(counter);
        }

        internal override void CreateCounter(long? runId = null, int? interval = null)
        {
            try
            {
                this.Instance.RunId = runId;
                this.HasCreated = true;
                this.OnLogged("EventLogCounter created");
                if (runId.HasValue && interval.HasValue)
                {
                    this.Start(runId.Value, interval.Value);
                }
            }
            catch (Exception ex)
            {
                this.OnExceptionOccurred(ex);
                this.KillCounter();
            }
        }

        internal override void Start(long runId, int interval)
        {
            this.toKill = false;
            this.Instance.RunId = runId;
            this.Interval = interval;
            this.Instance.Started = DateTime.Now.AddSeconds(this.TheEventLogCounter.DeferringStart.Value);
            this.HeartBeat();
            this.EnqueueRequest(runId, DateTime.Now, DateTime.Now.AddSeconds(this.Interval));
            if (this.HasCreated && this.timer == null)
            {
                this.timer = new Timer(new TimerCallback(TimerRun), null, this.TheEventLogCounter.DeferringStart.Value * 1000, this.Interval * 1000);
            }
            else
            {
                if (this.timer != null)
                {
                    this.timer.Change(this.TheEventLogCounter.DeferringStart.Value * 1000, this.Interval * 1000);
                }
            }
            this.OnLogged(string.Format("EventLogCounter will be started in {0} seconds", this.TheEventLogCounter.DeferringStart.Value));
        }

        private void TimerRun(object state)
        {
            try
            {
                if (!this.toKill)
                {
                    if (!this.behavior.IsPerforming)
                    {
                        //AdvancedTaskRequest request = this.DequeueRequest();
                        //if (request != null)
                        //{
                        //    this.queryingRunIds.Add(request);
                        //    while (this.Instance.RunId.HasValue && request.RunId != this.Instance.RunId.Value)
                        //    {
                        //        request = this.DequeueRequest();
                        //        if (request != null)
                        //        {
                        //            this.queryingRunIds.Add(request);
                        //        }
                        //    }
                        //    this.behavior.Perform(this.Instance.Machine, this.TheEventLogCounter, this.queryingRunIds);
                        //    this.queryingRunIds.Clear();
                        //    this.Instance.LastFetched = DateTime.Now;
                        //}
                        if (this.DequeueAllRequestes() > 0)
                        {
                            this.behavior.Perform(this.Instance.Machine, this.TheEventLogCounter, this.queryingRunIds);
                            this.queryingRunIds.Clear();
                            this.Instance.LastFetched = DateTime.Now;
                        }
                    }
                    // Check RunId if Pause() has been called or a new RunId has been set.
                    // Enqueque the next request for:
                    //      1. Within the same RunId, continue with next request.
                    //      2. The last request is being performed, but RunId has been changed and has enqueued a new request.
                    //          (in this case, this.lastRequest.End will be updated)
                    if (this.Instance.RunId.HasValue && 
                            (this.lastRequestDequeued == null || this.lastRequestDequeued.RunId == this.Instance.RunId.Value
                            || this.lastRequest.RunId == this.Instance.RunId.Value))
                    {
                        this.EnqueueNextRequest(this.Instance.RunId.Value, this.Interval);
                    }
                }
            }
            catch (System.Threading.ThreadAbortException)
            {
                //Thread was being aborted
            }
            catch (Exception ex)
            {
                this.OnExceptionOccurred(ex);
                this.FaultCounter();
            }
        }

        /// <summary>
        /// Notes: In most cases, it is called when this.behavior.Perform() is executing since it costs time.
        /// </summary>
        /// <param name="interval"></param>
        /// <param name="dueToCallerDead"></param>
        internal override void Pause(int interval, bool dueToCallerDead = false)
        {
            this.UpdateLastRequest(this.Instance.RunId.Value, DateTime.Now, this.Interval);
            if (dueToCallerDead)
            {
                this.OnLogged("EventLogCounter is requested to do the last query for this RunId due to the caller doesn't contact anymore");
            }
            else
            {
                this.OnLogged("EventLogCounter is requested to do the last query for this RunId");
            }
            this.Instance.RunId = null;
        }

        internal override void FaultCounter()
        {
            this.KillCounter();
        }

        internal override void KillCounter(bool dueToCallerDead = false)
        {
            this.toKill = true;
            this.Instance.RunId = null;
            this.Instance.Started = null;
            this.Instance.LastFetched = null;
            this.Instance.LastHeartBeat = null;
            this.queryingRunIds.Clear();
            this.requestedRunIds.Clear();
            if (this.HasCreated)
            {
                if (this.timer != null)
                {
                    this.timer.Dispose();
                    this.timer = null;
                }
                if (this.behavior.IsPerforming)
                {
                    this.behavior.Reset();
                }
                this.HasCreated = false;
                if (dueToCallerDead)
                {
                    this.OnLogged("EventLogCounter Killed due to the caller doesn't contact anymore");
                }
                else
                {
                    this.OnLogged("EventLogCounter Killed");
                }
            }
        }
    }

    [DataContract]
    public class SplunkTask : AdvancedTask
    {
        public SplunkTask(string machine, SplunkCounter counter, int interval)
        {
            this.Instance = new CounterInstance(machine, counter);
            this.Interval = interval;
            this.requestedRunIds = new Queue<AdvancedTaskRequest>();
            if (!counter.DeferringStart.HasValue || counter.DeferringStart.HasValue && counter.DeferringStart.Value != interval)
            {
                counter.DeferringStart = interval;
            }
            if (!counter.DeferringEnd.HasValue || counter.DeferringEnd.HasValue && counter.DeferringEnd.Value != interval)
            {
                counter.DeferringEnd = interval;
            }
        }

        internal override void CreateCounter(long? runId = null, int? interval = null)
        {
            throw new NotImplementedException();
        }

        internal override void Start(long runId, int interval)
        {
            throw new NotImplementedException();
        }

        internal override void Pause(int interval, bool dueToCallerDead = false)
        {
            throw new NotImplementedException();
        }

        internal override void FaultCounter()
        {
            throw new NotImplementedException();
        }

        internal override void KillCounter(bool dueToCallerDead = false)
        {
            throw new NotImplementedException();
        }
    }

}
