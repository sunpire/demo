﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace PMS.Core
{
    [DataContract]
    [Flags]
    public enum MonitoringType
    {
        [EnumMember]
        Basic = 1,
        [EnumMember]
        Advanced = 2,
        [EnumMember]
        All = Basic | Advanced
    }

    [DataContract]
    public enum TaskStatus
    {
        [EnumMember]
        NotCreated = 0,
        [EnumMember]
        Standby = 1,
        [EnumMember]
        Running = 2,
        [EnumMember]
        Invalid = 3,
        [EnumMember]
        Faulted = 4
    }

    [DataContract]
    public enum EventLogQueryMethodType
    {
        /// <summary>
        /// Default: Query EventLog directly
        /// </summary>
        [EnumMember]
        Default,
        /// <summary>
        /// Query via Wmi
        /// </summary>
        [EnumMember]
        Wmi
    }

    /// <summary>
    /// For EventLog Advanced Counter
    /// </summary>
    [DataContract]
    public enum EventLogEntryFilterType
    {
        /// <summary>
        /// Only by datetime range
        /// </summary>
        [EnumMember]
        None,
        [EnumMember]
        FromDescription
    }

    /// <summary>
    /// For EventLog Advanced Counter
    /// </summary>
    [DataContract]
    public enum EventLogEntryAggregationType
    {
        [EnumMember]
        None,
        [EnumMember]
        Count,
        [EnumMember]
        Avg,
        [EnumMember]
        Max,
        [EnumMember]
        Min,
    }

    /// <summary>
    /// Same as System.Diagnostics.EventLogEntryType
    /// </summary>
    [DataContract]
    [Flags]
    public enum EventLogEntryType
    {
        /// <summary>
        /// An error event. This indicates a significant problem the user should know about; usually a loss of functionality or data.
        /// </summary>
        [EnumMember]
        Error = 1,
        /// <summary>
        /// A warning event. This indicates a problem that is not immediately significant,but that may signify conditions that could cause future problems.
        /// </summary>
        [EnumMember]
        Warning = 2,
         /// <summary>
        /// An information event. This indicates a significant, successful operation.
        /// </summary>
        [EnumMember]
        Information = 4,
        /// <summary>
        /// A success audit event. This indicates a security event that occurs when an audited access attempt is successful; for example, logging on successfully.
        /// </summary>
        [EnumMember]
        SuccessAudit = 8,
        /// <summary>
        /// A failure audit event. This indicates a security event that occurs when an audited access attempt fails; for example, a failed attempt to open a file.
        /// </summary>
        [EnumMember]
        FailureAudit = 16
    }
        
    [KnownTypeAttribute(typeof(PerfMonCounter))]
    [KnownTypeAttribute(typeof(EventLogCounter))]
    [KnownTypeAttribute(typeof(SplunkCounter))]
    [DataContract]
    public abstract class Counter
    {
        [DataMember(Order = 1)]
        public int Id { get; set; }

        [DataMember(Order = 2)]
        public string FriendlyName { get; set; }

        [DataMember(Order = 3)]
        public bool IsInteger { get; set; }

        protected string key;
        /// <summary>
        /// Full name of the counter
        /// </summary>
        public virtual string CounterKey
        {
            get
            {
                if (!string.IsNullOrEmpty(this.FriendlyName))
                {
                    return this.FriendlyName;
                }
                else
                {
                    return key;
                }
            }
        }

        protected string safeKey;
        /// <summary>
        /// Full name of the counter, but it is restricted within 50 letters
        /// </summary>
        public virtual string SafeCounterKey
        {
            get
            {
                if (!string.IsNullOrEmpty(this.FriendlyName))
                {
                    return this.FriendlyName;
                }
                else
                {
                    return safeKey;
                }
            }
        }

        public override int GetHashCode()
        {
            return this.CounterKey.GetHashCode();
        }
        
        public override string ToString()
        {
            return string.Format("[ID_{0}({1})]", this.Id, this.SafeCounterKey);
        }
    }

    [DataContract]
    public class PerfMonCounter : Counter
    {
        [DataMember(Order = 1)]
        public string Category { get; set; }

        [DataMember(Order = 2)]
        public string Name { get; set; }

        [DataMember(Order = 3)]
        public string Instance { get; set; }

        /// <summary>
        /// Full name of the counter
        /// </summary>
        public override string CounterKey
        {
            get
            {
                if (!string.IsNullOrEmpty(this.FriendlyName))
                {
                    return this.FriendlyName;
                }
                else
                {
                    if (key == null)
                    {
                        key = string.Format(@"{0}\{1}\{2}", this.Category, this.Name, this.Instance);
                    }
                    return key;
                }
            }
        }

        /// <summary>
        /// Full name of the counter, but it is restricted within 50 letters
        /// </summary>
        public override string SafeCounterKey
        {
            get
            {
                if (!string.IsNullOrEmpty(this.FriendlyName))
                {
                    return this.FriendlyName;
                }
                else
                {
                    if (safeKey == null)
                    {
                        if (this.CounterKey.Length > 50)
                        {
                            safeKey = string.Concat(
                                                this.CounterKey.Substring(0, 49 - this.Id.ToString().Length),
                                                "~",
                                                this.Id);
                        }
                        else
                        {
                            safeKey = this.CounterKey;
                        }
                    }
                    return safeKey;
                }                
            }
        }

        public PerfMonCounter(string category, string counter, string instance)
        {
            this.Category = category;
            this.Name = counter;
            this.Instance = instance;
        }


        public override bool Equals(object obj)
        {
            if (obj is PerfMonCounter)
            {
                return this.GetHashCode().Equals(((PerfMonCounter)obj).GetHashCode());
            }
            else if (obj is PerfMonCounterConfig)
            {
                return this.GetHashCode().Equals((FromConfig((PerfMonCounterConfig)obj)).GetHashCode());
            }
            else
            {
                return false;
            }
        }

        public static PerfMonCounter FromConfig(PerfMonCounterConfig cc)
        {
            return new PerfMonCounter(cc.Category, cc.Name, string.IsNullOrEmpty(cc.Instance) ? string.Empty : cc.Instance)
            {
                Id = cc.Id, 
                FriendlyName = cc.FriendlyName,
                IsInteger = cc.IsInteger
            };
        }
    }

    [KnownTypeAttribute(typeof(EventLogCounter))]
    [KnownTypeAttribute(typeof(SplunkCounter))]
    [DataContract]
    public abstract class AdvancedCounter : Counter
    {
        [DataMember(Order = 1)]
        public int? DeferringStart { get; set; }

        [DataMember(Order = 2)]
        public int? DeferringEnd { get; set; }
    }

    [DataContract]
    public class EventLogCounter : AdvancedCounter
    {
        [DataMember(Order = 0)]
        public EventLogQueryMethodType QueryMethod { get; set; }

        /// <summary>
        /// Application, System, etc
        /// </summary>
        [DataMember(Order = 1)]
        public string LogName { get; set; }

        [DataMember(Order = 2)]
        public EventLogEntryType EntryType { get; set; }

        [DataMember(Order = 3)]
        public string Source { get; set; }

        [DataMember(Order = 4)]
        public string Category { get; set; }

        [DataMember(Order = 5)]
        public int? EventCode { get; set; }

        [DataMember(Order = 11)]
        public EventLogEntryFilterType FilterType { get; set; }

        [DataMember(Order = 12)]
        public EventLogEntryAggregationType GroupType { get; set; }

        /// <summary>
        /// The same meaning as 'timespan' in Splunk query.
        /// It needs to divide the filtered out EventLog entries into groups by timespan
        /// </summary>
        [DataMember(Order = 13)]
        public int TimeScale { get; set; }

        [DataMember(Order = 14)]
        public string FilteredBy { get; set; }

        [DataMember(Order = 15)]
        public string GroupBy { get; set; }

        /// <summary>
        /// E.g., 'GroupBy EventCode' may lead to groups EventCode1, EventCode2, EventCode3... to be outputted
        /// </summary>
        [DataMember(Order = 16)]
        public bool UseGroupValueToFormFriendlyName { get; set; }


        public override bool Equals(object obj)
        {
            if (obj is EventLogCounter)
            {
                return this.GetHashCode().Equals(((EventLogCounter)obj).GetHashCode());
            }
            else if (obj is EventLogCounterConfig)
            {
                return this.GetHashCode().Equals((FromConfig((EventLogCounterConfig)obj)).GetHashCode());
            }
            else
            {
                return false;
            }
        }

        public static EventLogCounter FromConfig(EventLogCounterConfig cc)
        {
            return new EventLogCounter()
            {
                Id = cc.Id,
                IsInteger = cc.IsInteger,
                FriendlyName = cc.FriendlyName,
                DeferringStart = cc.DeferringStart ?? cc.Interval,
                DeferringEnd = cc.DeferringEnd ?? cc.Interval,
                QueryMethod = cc.QueryMethod,
                LogName = cc.LogName,
                EntryType = ToEntryType(cc.EntryType),
                Source = cc.Source,
                Category = cc.Category,
                EventCode = cc.EventCode,
                FilterType = cc.FilterType,
                FilteredBy = cc.FilteredBy,
                GroupType = cc.GroupType,
                GroupBy = cc.GroupBy,
                TimeScale = cc.TimeScale,
                UseGroupValueToFormFriendlyName = cc.UseGroupValueToFormFriendlyName
            };
        }

        /// <summary>
        /// Supports delimiter '|', Information|Error is valid.
        /// </summary>
        /// <param name="entryType"></param>
        /// <returns></returns>
        public static EventLogEntryType ToEntryType(string entryType)
        {
            if (entryType.IndexOf("|") > 0)
            {
                string[] entryTypes = entryType.Split(new[] { '|' });
                EventLogEntryType type = (EventLogEntryType)Enum.Parse(typeof(EventLogEntryType), entryTypes[0]);
                for (int i = 1; i < entryTypes.Length; i++ )
                {
                    type = type | (EventLogEntryType)Enum.Parse(typeof(EventLogEntryType), entryTypes[i]);
                }
                return type;
            }
            else
            {
                return (EventLogEntryType)Enum.Parse(typeof(EventLogEntryType), entryType);
            }
        }

        /// <summary>
        /// Convert to System.Diagnostics.EventLogEntryType
        /// </summary>
        /// <returns></returns>
        public System.Diagnostics.EventLogEntryType ConvertEntryType()
        {
            return (System.Diagnostics.EventLogEntryType)Enum.Parse(typeof(System.Diagnostics.EventLogEntryType), ((byte)this.EntryType).ToString());
        }
    }

    [DataContract]
    public class SplunkCounter : AdvancedCounter
    {
        [DataMember(Order = 1)]
        public string Query { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is SplunkCounter)
            {
                return this.GetHashCode().Equals(((SplunkCounter)obj).GetHashCode());
            }
            else if (obj is SplunkCounterConfig)
            {
                return this.GetHashCode().Equals((FromConfig((SplunkCounterConfig)obj)).GetHashCode());
            }
            else
            {
                return false;
            }
        }

        public static SplunkCounter FromConfig(SplunkCounterConfig cc)
        {
            return new SplunkCounter()
            {
                Id = cc.Id,
                IsInteger = cc.IsInteger,
                FriendlyName = cc.FriendlyName,
                DeferringStart = cc.DeferringStart ?? cc.Interval,
                DeferringEnd = cc.DeferringEnd ?? cc.Interval,
                Query = cc.Query
            };
        }
    }

    [DataContract]
    public class CounterInstance
    {
        [DataMember(Name = "Counter", Order = 1)]
        public Counter TheCounter { get; set; }

        [DataMember(Order = 3)]
        public string Machine { get; set; }

        [DataMember(Name = "RunId", Order = 4)]
        public long? RunId { get; set; }

        [DataMember(Order = 5)]
        public DateTime? Started { get; set; }

        [DataMember(Order = 6)]
        public DateTime? LastFetched { get; set; }

        [DataMember(Order = 7)]
        public DateTime? LastHeartBeat { get; set; }

        public string Key { get; private set; }

        public bool IsRunning { get { return this.RunId.HasValue; } }

        public CounterInstance(string machine, Counter counter)
        {
            this.TheCounter = counter;
            this.Machine = machine != null ? machine.ToUpper() : string.Empty;
            this.Key = string.Format("Machine: {0}, {1}", this.Machine, this.TheCounter);
        }

        public override string ToString()
        {
            return string.Format("[RunId: {0} on {1} {2}]", this.IsRunning ? this.RunId.Value.ToString() : "null", this.Machine, this.TheCounter);
        }

        public bool IsTheSameMachine(string machine)
        {
            return string.Equals(this.Machine, machine, StringComparison.CurrentCultureIgnoreCase);
        }
    }

    [DataContract]
    public class Data
    {
        [DataMember(Order = 2)]
        public DateTime LoggedTime { get; set; }

        [DataMember(Order = 1)]
        public float Value { get; set; }

        public override string ToString()
        {
            return string.Format("Value: {0} at {1}", this.Value, this.LoggedTime);
        }
    }


}
