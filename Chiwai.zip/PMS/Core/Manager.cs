﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PMS.Core
{
    /// <summary>
    /// Tasks co-ordinator, also it is a Task Factory
    /// </summary>
    public class Manager
    {
        #region Fields
        private static object syncRoot = new Object();

        private List<Task> tasks;

        private PerformanceMonitorConfig config;

        /// <summary>
        /// The default interval for DryRun
        /// </summary>
        private const int DryRunInterval = 600;

        /// <summary>
        /// The max time(in seconds) to allow a PerformanceCounter keeps working since last time when the caller let the service know it's still alive
        /// </summary>
        private int keepAlive;

        /// <summary>
        /// The Timer to check callers are alive
        /// </summary>
        private Timer keepAliveTimer;

        /// <summary>
        /// The timer to clean up idle tasks, unlike BasicTask, AdvancedTask does not need to keep the Standby state
        /// </summary>
        private Timer cleanUpTimer;
        #endregion

        public Manager(PerformanceMonitorConfig config)
        {
            this.tasks = new List<Task>();
            this.config = config;
            Task.LogFetchedValues = config.LogFetchedValues;
            Task.LogDebugMessage = config.LogDebugMessage;
            DbLogger.Instance.ConnectionString = config.LogDbConnectionString;
            
            if (config.Machines != null)
            {
                if (config.EnabledBasicCounters.Count > 0)
                {
                    IEnumerable<MachineEntry> machines = config.Machines.Where(m => m.MonitoringType.HasFlag(MonitoringType.Basic));
                    foreach (MachineEntry machine in machines)
                    {
                        foreach (CounterConfig cc in config.EnabledBasicCounters)
                        {
                            this.CreateSingleTask(MonitoringType.Basic, machine.MachineName, cc, DryRunInterval, false);
                        }
                    }
                }

                if (config.EnabledAdvancedCounters.Count > 0)
                {
                    IEnumerable<MachineEntry> machines = config.Machines.Where(m => m.MonitoringType.HasFlag(MonitoringType.Advanced));
                    foreach (MachineEntry machine in machines)
                    {
                        foreach (CounterConfig cc in config.EnabledAdvancedCounters)
                        {
                            this.CreateSingleTask(MonitoringType.Advanced, machine.MachineName, cc, DryRunInterval, false);                     
                        }
                    }
                }
            }
            this.keepAlive = config.KeepAlive;
            this.keepAliveTimer = new Timer(new TimerCallback(KeepAliveTimerRun), null, 60000, 60000);
            this.cleanUpTimer = new Timer(new TimerCallback(CleanUpTimerRun), null, 600000, 600000);
        }

        #region Create and Work
        /// <summary>
        /// Creates a single Task (and initializes a PerformanceCounter if createCounter = true)
        /// </summary>
        /// <param name="type"></param>
        /// <param name="machine"></param>
        /// <param name="ce"></param>
        /// <param name="interval"></param>
        /// <param name="createCounter">if true, initializes counter</param>
        /// <param name="runId">if specified, run after initializing</param>
        /// <returns></returns>
        private Task CreateSingleTask(MonitoringType type, string machine, CounterConfig ce, int interval, bool createCounter = true, long? runId = null)
        {
            if (!Helper.CanResolveMachineName(machine))
            {
                return null;
            }
            
            Task t;
            if (type == MonitoringType.Basic)
            {
                t = new BasicTask(machine, (PerfMonCounter)CouterFactory.FromConfig(ce), interval);
            }
            else
            {
                AdvancedCounter advCounter = (AdvancedCounter)CouterFactory.FromConfig(ce);
                if (advCounter is EventLogCounter)
                {
                    t = new EventLogTask(machine, (EventLogCounter)advCounter, interval);
                }
                else
                {
                    t = new SplunkTask(machine, (SplunkCounter)advCounter, interval);
                }
            }
            this.tasks.Add(t);
            if (createCounter)
            {
                t.CreateCounter(runId, interval);
            }
            return t;
        }

        public List<Task> CreateAllTasks()
        {
            foreach (Task t in this.tasks)
            {
                t.CreateCounter();
            }
            return this.GetAllTasks(); 
        }

        public Task[] CreateTasksOnMachine(string machine, MonitoringType monitoringType)
        {
            lock (syncRoot)
            {
                if (monitoringType.HasFlag(MonitoringType.Basic))
                {
                    this.CreateTasksOnMachine(machine, config.EnabledBasicCounters, MonitoringType.Basic);
                }
                if (monitoringType.HasFlag(MonitoringType.Advanced))
                {
                    this.CreateTasksOnMachine(machine, config.EnabledAdvancedCounters, MonitoringType.Advanced);
                }
                return this.tasks.Where(t => t.Instance.IsTheSameMachine(machine) && this.IsMonitoringTask(t, monitoringType)).ToArray();
            }
        }

        private void CreateTasksOnMachine(string machine, List<CounterConfig> enabledCounters, MonitoringType monitoringType)
        {
            foreach (CounterConfig cc in enabledCounters)
            {
                Task t = this.tasks.SingleOrDefault(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Equals(cc));
                if (t == null)
                {
                    t = this.CreateSingleTask(monitoringType, machine, cc, DryRunInterval);
                }
                else
                {
                    if (t.Instance.IsRunning)
                    {
                        t.ChangeInterval(DryRunInterval);
                    }
                    else
                    {
                        t.ChangeInterval(DryRunInterval);
                        t.CreateCounter();
                    }
                }
            }
        }

 
        public Task[] WorkOnMachine(string machine, MonitoringType monitoringType, long runId, string intervalText)
        {
            int intervalValue = this.ToInterval(intervalText);
            lock (syncRoot)
            {
                if (monitoringType.HasFlag(MonitoringType.Basic))
                {
                    this.WorkOnMachine(machine, config.EnabledBasicCounters, runId, intervalValue);                    
                }
                if (monitoringType.HasFlag(MonitoringType.Advanced))
                {
                    this.WorkOnMachine(machine, config.EnabledAdvancedCounters, runId, intervalValue);
                }
                return this.tasks.Where(t => t.Instance.IsTheSameMachine(machine) && t.Instance.IsRunning && t.Instance.RunId == runId && this.IsMonitoringTask(t, monitoringType)).ToArray();
            }
        }

        private void WorkOnMachine(string machine, List<CounterConfig> enabledCounters, long runId, int intervalValue)
        {
            foreach (CounterConfig cc in enabledCounters)
            {
                int interval = intervalValue == 0 ? cc.Interval : intervalValue;
                Task t = this.tasks.SingleOrDefault(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Equals(cc));
                if (t != null)
                {
                    if (!t.HasCreated)
                    {
                        t.CreateCounter(runId);
                    }
                    else
                    {
                        t.Start(runId, interval);
                    }
                }
            }
        }

        public Task[] CreateCounterAndWorkOnMachine(string machine, MonitoringType monitoringType, long runId, string intervalText)
        {
            int intervalValue = this.ToInterval(intervalText);
            lock (syncRoot)
            {
                if (monitoringType.HasFlag(MonitoringType.Basic))
                {
                    this.CreateCounterAndWorkOnMachine(machine, config.EnabledBasicCounters, MonitoringType.Basic, runId, intervalValue);
                }
                if (monitoringType.HasFlag(MonitoringType.Advanced))
                {
                    this.CreateCounterAndWorkOnMachine(machine, config.EnabledAdvancedCounters, MonitoringType.Advanced, runId, intervalValue);
                }
                return this.tasks.Where(t => t.Instance.IsTheSameMachine(machine) && this.IsMonitoringTask(t, monitoringType)).ToArray();
            }
        }

        private void CreateCounterAndWorkOnMachine(string machine, List<CounterConfig> enabledCounters, MonitoringType monitoringType, long runId, int intervalValue)
        {
            foreach (CounterConfig cc in enabledCounters)
            {
                int interval = intervalValue == 0 ? cc.Interval : intervalValue;
                Task t = this.tasks.SingleOrDefault(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Equals(cc));
                if (t == null)
                {
                    this.CreateSingleTask(monitoringType, machine, cc, interval, true, runId);
                }
                else
                {
                    if (!t.HasCreated)
                    {
                        t.CreateCounter(runId, interval);
                    }
                    else
                    {
                        t.Start(runId, interval);
                    }
                }
            }
        }
        #endregion

        #region Get
        public Task[] GetTasksOnMachine(string machine)
        {
            return this.tasks.Where(tsk => tsk.Instance.IsTheSameMachine(machine)).ToArray();
        }

        public Task[] GetTasksOnMachine(string machine, MonitoringType monitoringType)
        {
            return this.tasks.Where(t => t.Instance.IsTheSameMachine(machine) && this.IsMonitoringTask(t, monitoringType)).ToArray();
        }

        public Task[] GetAllRunningCounters(MonitoringType monitoringType)
        {
            return this.tasks.Where(t => t.Instance.IsRunning && this.IsMonitoringTask(t, monitoringType)).ToArray();
        }

        public List<Task> GetAllTasks()
        {
            return this.tasks;
        }
        #endregion

        #region Stop & Kill
        public Task[] StopTasks(long runId, string intervalText)
        {
            int intervalValue = this.ToInterval(intervalText);
            lock (syncRoot)
            {
                Task[] ts = this.tasks.Where(t => (t.Instance.IsRunning && t.Instance.RunId == runId) ||
                                                    (t.IsCreating && t.RunIdInCreating.HasValue && t.RunIdInCreating.Value == runId)).ToArray();
                Parallel.ForEach<Task>(ts, (t) =>
                {
                    t.Pause(intervalValue == 0 ? DryRunInterval : intervalValue);
                });
                //foreach (Task t in ts)
                //{
                //    t.Pause(intervalValue == 0 ? DryRunInterval : intervalValue);
                //}
                return ts;
            }
        }

        public void StopAllTasks(string intervalText)
        {
            int intervalValue = this.ToInterval(intervalText);
            lock (syncRoot)
            {
                Parallel.ForEach<Task>(this.tasks, (t) =>
                {
                    t.Pause(intervalValue == 0 ? DryRunInterval : intervalValue);
                });
                //foreach (Task t in this.tasks)
                //{
                //    t.Pause(intervalValue == 0 ? DryRunInterval : intervalValue);
                //}
            }
        }

        public void KillTasksOnMachine(string machine)
        {
            lock (syncRoot)
            {
                // Task maybe stopped
                IEnumerable<Task> ts = this.tasks.Where(t => t.Instance.IsTheSameMachine(machine));
                Parallel.ForEach<Task>(ts, (t) =>
                {
                    t.KillCounter();
                });
                //foreach (Task t in ts)
                //{
                //    t.KillCounter();
                //}
            }
        }

        public void KillAllTasks()
        {
            lock (syncRoot)
            {
                Parallel.ForEach<Task>(this.tasks, (t) =>
                {
                    t.KillCounter();
                });
                //foreach (Task t in this.tasks)
                //{
                //    t.KillCounter();
                //}

                DbLogger.Instance.Kill();
                while (this.tasks.Any(t => t.HasCreated))
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
        }

        public void ShutDown()
        {
            this.KillAllTasks();
            if (this.keepAliveTimer != null)
            {
                this.keepAliveTimer.Dispose();
                this.keepAliveTimer = null;
            }
            if (this.cleanUpTimer != null)
            {
                this.cleanUpTimer.Dispose();
                this.cleanUpTimer = null;
            }
        }

        #region CleanUp
        private void CleanUpTimerRun(object state)
        {
            lock (syncRoot)
            {
                try
                {
                    IEnumerable<Task> tasksToKill = this.tasks.Where(t => !t.Instance.IsRunning &&
                                                            t is AdvancedTask && ((AdvancedTask)t).IsIdle);
                    Parallel.ForEach<Task>(tasksToKill, (t) =>
                    {
                        t.KillCounter(false);
                    });
                    //foreach (AdvancedTask t in tasksToKill)
                    //{
                    //    t.KillCounter(false);
                    //}
                }
                catch (System.Threading.ThreadAbortException)
                {
                    //Thread was being aborted
                }
                catch (Exception)
                {
                }
            }
        }
        #endregion

        #region Keep Alive
        public int HeartBeat(long runId)
        {
            lock (syncRoot)
            {
                IEnumerable<Task> tasksToHeartBeat = this.tasks.Where(t => t.Instance.IsRunning && t.Instance.RunId == runId);
                Parallel.ForEach<Task>(tasksToHeartBeat, (t) =>
                {
                    t.HeartBeat();
                });
                //foreach (Task t in tasksToHeartBeat)
                //{
                //    t.HeartBeat();
                //}
                return tasksToHeartBeat.Count();
            }
        }        

        private void KeepAliveTimerRun(object state)
        {
            lock (syncRoot)
            {
                try
                {
                    IEnumerable<Task> tasksToKill = this.tasks.Where(t => t.Instance.IsRunning &&
                                (DateTime.Now - t.Instance.LastHeartBeat.Value).TotalSeconds >= this.keepAlive);
                    Parallel.ForEach<Task>(tasksToKill, (t) =>
                    {
                        t.Pause(DryRunInterval, true);
                    });
                    //foreach (Task t in tasksToKill)
                    //{
                    //    t.Pause(DryRunInterval, true);
                    //}
                }
                catch (System.Threading.ThreadAbortException)
                {
                    //Thread was being aborted
                }
                catch (Exception)
                {
                }
            }
        }
        #endregion
        #endregion

        #region SingleTask
        public void SetIntervalSingleTask(string machine, Counter counter, int interval)
        {
            this.tasks.Single(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Id == counter.Id)
                        .ChangeInterval(interval);
        }

        public void WorkSingleTask(string machine, Counter counter, long runId, int interval)
        {
            this.tasks.Single(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Id == counter.Id)
                        .Start(runId, interval);
        }

        public void StopSingleTask(string machine, Counter counter)
        {
            this.tasks.Single(tsk => tsk.Instance.IsTheSameMachine(machine) && tsk.Instance.TheCounter.Id == counter.Id)
                        .Pause(DryRunInterval);
        }
        #endregion

        internal bool IsMonitoringTask(Task t, MonitoringType targetType)
        {
            if (targetType == MonitoringType.All)
            {
                return true;
            }
            if (targetType == MonitoringType.Basic)
            {
                return t is BasicTask;
            }
            else
            {
                return t is AdvancedTask;
            }
        }

        private int ToInterval(string intervalText)
        {
            int intervalValue = 0;
            if (!string.IsNullOrEmpty(intervalText) && !int.TryParse(intervalText, out intervalValue))
            {
                intervalValue = 0;
            }
            return intervalValue;
        }
    }
}
