﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace PMS.Core
{
    /// <summary>
    /// Common ADO.NET Data Access Layer
    /// </summary>
    public class Db
    {
        #region Connection
        private static string commonConnString = null;

        public static string CommonConnectionString
        {
            get { return Db.commonConnString; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    Db.commonConnString = value;
                }
                else
                {
                    throw new System.ArgumentException("Common Connection String can not be empty.");
                }
            }
        }
        
        private string connString;        
        public string ConnectionString
        {
            get { return this.connString; }
            set { this.connString = value; }
        }

        private System.Data.Common.DbConnection transConn;
        public System.Data.Common.DbConnection Connection
        {
            get { return transConn; }
            set
            {
                transConn = value;
                this.connString = transConn.ConnectionString;
            }
        }

        public bool IsConnectionOpen
        {
            get
            {
                if (this.transConn != null && this.transConn.State == System.Data.ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public System.Data.Common.DbConnection CreateConnection()
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            conn.ConnectionString = this.connString;
            return conn;
        }

        public bool CreateActiveConnection()
        {
            try
            {
                if (this.transConn == null)
                {
                    this.transConn = this.factory.CreateConnection();
                    this.transConn.ConnectionString = this.connString;
                }
                if (!this.IsConnectionOpen)
                {
                    this.transConn.Open();
                }
                return true;
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex);
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex);
            }
            return false;
        }

        public bool CloseActiveConnection()
        {
            if (this.IsConnectionOpen)
            {
                try
                {
                    this.transConn.Close();
                    this.transConn.Dispose();
                    this.transConn = null;
                    return true;
                }
                catch (InvalidOperationException ex)
                {
                    Logger.Instance.Log(ex);
                }
                catch (Exception ex)
                {
                    Logger.Instance.Log(ex);
                }
                return false;
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region GetFactoryByConfig()
        public Db()
            : this(Db.CommonConnectionString, "MSSql")
        {
        }

        public Db(string connectionString)
            : this(connectionString, "MSSql")
        {
        }

        public Db(string connectionString, string dbProvider)
        {
            if (!string.IsNullOrEmpty(connectionString))
            {
                this.connString = connectionString;
            }
            else
            {
                throw new System.ArgumentException("Given connection string can not be empty.");
            }
            DbProviderFactory fact = this.GetFactoryByConfig(dbProvider);
            if (fact != null)
            {
                this.factory = fact;
            }
            else
            {
                throw new System.ArgumentException("Given dbProvider is not support.");
            }
        }

        /// <summary>
        /// .NET 2.0 DbProviderFactory
        /// </summary>
        private DbProviderFactory factory = null;        
        private DbProviderFactory GetFactoryByConfig(string config)
        {
            if (config.ToLower() == "MSSql".ToLower())
            {
                //System.Data.SqlClient.SqlClientFactory.Instance
                return DbProviderFactories.GetFactory("System.Data.SqlClient");
            }
            else if (config.ToLower() == "SQLite".ToLower())
            {
                return DbProviderFactories.GetFactory("System.Data.SQLite");
                //return new System.Data.SQLite.SQLiteFactory();
            }
            else if (config.ToLower() == "OleDb".ToLower())
            {
                return System.Data.OleDb.OleDbFactory.Instance;
                //return DbProviderFactories.GetFactory("System.Data.OleDbClient");
            }
            else if (config.ToLower() == "Oracle".ToLower())
            {
                return DbProviderFactories.GetFactory("System.Data.OracleClient");
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region Command and Parameters
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbCommand CreateCommand(string commandText)
        {
            DbCommand cmd = this.factory.CreateCommand();
            if (!string.IsNullOrEmpty(commandText))
            {
                cmd.CommandText = commandText;
            }
            return cmd;
        }
        
        public object GetParameterValue(System.Data.Common.DbCommand command, string parameterName)
        {
            try
            {
                return command.Parameters[parameterName].Value;
            }
            catch (IndexOutOfRangeException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        private string GetCommandDetail(System.Data.Common.DbCommand c)
        {
            System.Text.StringBuilder b = new System.Text.StringBuilder(System.Environment.NewLine + "CommandText:");
            b.AppendLine(c.CommandText);
            b.AppendLine("Parameters:");
            foreach (System.Data.Common.DbParameter p in c.Parameters)
            {
                b.Append(p.ParameterName);
                b.Append(" ");
                b.Append(p.DbType.ToString());
                b.Append(" = ");
                if (p.Value != null && !p.Value.Equals(System.DBNull.Value))
                {
                    b.AppendLine(p.Value.ToString());
                }
                else
                {
                    b.AppendLine("null");
                }
            }
            return b.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public System.Data.Common.DbParameter CreateParameter()
        {
            return this.factory.CreateParameter();
        }
        
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, object value)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.Value = value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, object value, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Value = value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, System.Data.Common.DbParameter parameter)
        {
            command.Parameters.Add(parameter);
            return parameter;
        }        

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size, string srcColumn)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.SourceColumn = srcColumn;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size, string srcColumn, System.Data.DataRowVersion version)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.SourceColumn = srcColumn;
            p.SourceVersion = version;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, string srcColumn, System.Data.DataRowVersion version)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.SourceColumn = srcColumn;
            p.SourceVersion = version;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            p.DbType = type;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }

        public System.Data.Common.DbParameter AppendReturnParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.ReturnValue;
            p.ParameterName = parameterName;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }


        #endregion

        #region ToDbValue
        public static void SetValueToDbInt(System.Data.Common.DbParameter parameter, string stringValue)
        {
            if (string.IsNullOrEmpty(stringValue))
            {
                parameter.Value = System.DBNull.Value;
            }
            else
            {
                int result;
                if (int.TryParse(stringValue, out result))
                {
                    parameter.Value = result;
                }
                else
                {
                    parameter.Value = System.DBNull.Value;
                }
            }
        }

        public static void SetValueToDbDecimal(System.Data.Common.DbParameter parameter, string stringValue)
        {
            if (string.IsNullOrEmpty(stringValue))
            {
                parameter.Value = System.DBNull.Value;
            }
            else
            {
                decimal result;
                if (decimal.TryParse(stringValue, out result))
                {
                    parameter.Value = result;
                }
                else
                {
                    parameter.Value = System.DBNull.Value;
                }
            }
        }

        public static object ToDbValue(string theValue)
        {
            if (string.IsNullOrEmpty(theValue))
            {
                return System.DBNull.Value;
            }
            else
            {
                return theValue;
            }
        }
        
        public static object ToDbValue(object theValue)
        {
            return theValue == null ? System.DBNull.Value : (string.IsNullOrEmpty(theValue.ToString()) ? System.DBNull.Value : theValue);

        }
        #endregion

        #region Query and NonQuery
        #region Query
        #region ExecuteScalar
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public object ExecuteScalar(string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            object rst = null;
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 0;
                conn.Open();

                rst = selectCommand.ExecuteScalar();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText);
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText);
            }
            catch (Exception ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText);
            }
            finally
            {
                conn.Close();
            }
            return rst;
        }

        public object ExecuteScalar(string connectionString, string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.ExecuteScalar(connectionString, selectCommand);
            }
        }

        public object ExecuteScalar(System.Data.Common.DbCommand selectCommand)
        {
            return this.ExecuteScalar(this.connString, selectCommand);
        }

        public object ExecuteScalar(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.ExecuteScalar(this.connString, selectCommand);
            }
        }

        public bool DoesDataExist(string connectionString, string selectCommandText)
        {
            return this.ExecuteScalar(connectionString, selectCommandText) != null;
        }

        public bool DoesDataExist(string selectCommandText)
        {
            return this.DoesDataExist(this.connString, selectCommandText);
        }

        public bool DoesDataExist(System.Data.Common.DbCommand selectCommand)
        {
            return this.ExecuteScalar(this.connString, selectCommand) != null;
        }
        #endregion

        #region Schema
        /// <summary>
        /// Returns schema information for the data source of this System.Data.Common.DbConnection
        /// </summary>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema()
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema();
            }
        }

        /// <summary>
        /// Returns schema information for the data source of this System.Data.Common.DbConnection
        /// using the specified string for the schema name.
        /// </summary>
        /// <param name="collectionName">Specifies the name of the schema to return</param>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema(string collectionName)
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema(collectionName);
            }
        }
        /// <summary>
        ///              Returns schema information for the data source of this System.Data.Common.DbConnection
        ///              using the specified string for the schema name and the specified string array
        ///              for the restriction values.
        /// </summary>
        /// <param name="collectionName">Specifies the name of the schema to return</param>
        /// <param name="restrictionValues">Specifies a set of restriction values for the requested schema</param>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema(string collectionName, string[] restrictionValues)
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema(collectionName, restrictionValues);
            }
        }
        #endregion

        #region GetDataTable
        public System.Data.DataTable GetDataTable(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetDataTable(this.connString, selectCommand);
            }
        }

        public System.Data.DataTable GetDataTable(System.Data.Common.DbCommand selectCommand)
        {
            return this.GetDataTable(this.connString, selectCommand);
        }

        public System.Data.DataTable GetDataTable(string connectionString, string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetDataTable(connectionString, selectCommand);
            }
        }

        public System.Data.DataTable GetDataTable(string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 120;
                conn.Open();
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText);
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText, ex);
            }
            catch (Exception ex)
            {
                Logger.Instance.Log(ex, selectCommand.CommandText);
            }
            finally
            {
                conn.Close();
            }
            return table == null ? new System.Data.DataTable() : table;
        }
        #endregion
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// DbCommand.ExecuteNonQuery()
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string connectionString, System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandTimeout = 0;
                conn.Open();
                return command.ExecuteNonQuery();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            finally
            {
                conn.Close();
            }
            return -1;

        }

        public int ExecuteNonQuery(System.Data.Common.DbCommand command)
        {
            return this.ExecuteNonQuery(this.connString, command);
        }

        public int ExecuteNonQuery(string commandText)
        {
            using (DbCommand command = this.CreateCommand(commandText))
            {
                return this.ExecuteNonQuery(this.connString, command);
            }
        }
        #endregion

        #region ExecuteProcedure
        public int ExecuteProcedure(string connectionString, System.Data.Common.DbCommand command)
        {
            int result = -1;
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.Common.DbParameter parameter = null;
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                parameter = this.AppendReturnParameter(command, "@Return");
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            finally
            {
                result = (int)parameter.Value;
                conn.Close();
            }
            return result;

        }

        public int ExecuteProcedure(System.Data.Common.DbCommand command)
        {
            return this.ExecuteProcedure(this.connString, command);
        }

        /// <summary>
        /// Execute stored procedure with active connection
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteProcedureWithConnection(System.Data.Common.DbCommand command)
        {
            int result = -1;
            if (!this.CreateActiveConnection())
            {
                return result;
            }
            System.Data.Common.DbParameter parameter = null;
            try
            {
                command.Connection = this.transConn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                parameter = this.AppendReturnParameter(command, "@Return");
                command.ExecuteNonQuery();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            finally
            {
                result = (int)parameter.Value;
            }
            return result;
        }

        #endregion

        #region ExecuteProcedureForDataTable
        public System.Data.DataTable ExecuteProcedureForDataTable(string connectionString, System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                conn.Open();

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }

                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            catch (System.Data.Common.DbException ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            catch (Exception ex)
            {
                Logger.Instance.Log(ex, this.GetCommandDetail(command));
            }
            finally
            {
                conn.Close();
            }
            return table;

        }

        public System.Data.DataTable ExecuteProcedureForDataTable(System.Data.Common.DbCommand command)
        {
            return this.ExecuteProcedureForDataTable(this.connString, command);
        }
        #endregion

        #region DbDataAdapter
        public System.Data.Common.DbDataAdapter CreateDataAdapter(string connectionString, string selectCommandText)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            adapter.SelectCommand.Connection = conn;
            adapter.SelectCommand = conn.CreateCommand();
            adapter.SelectCommand.CommandText = selectCommandText;
            return adapter;
        }

        public System.Data.Common.DbDataAdapter CreateDataAdapter(string selectCommandText)
        {
            return this.CreateDataAdapter(this.connString, selectCommandText);
        }

        public System.Data.Common.DbDataAdapter CreateDataAdapter(System.Data.Common.DbCommand selectCommand)
        {
            if (selectCommand.Connection == null)
            {
                selectCommand.Connection = this.factory.CreateConnection();
                selectCommand.Connection.ConnectionString = this.connString;
            }
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = selectCommand;
            return adapter;
        }

        public System.Data.Common.DbDataAdapter CreateDataAdapter()
        {
            return this.factory.CreateDataAdapter();
        }

        #region DbDataAdapter.Fill()
        /// <summary>
        /// DbDataAdapter.Fill(DataTable)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            int result = -1;
            try
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection == null)
                {
                    adapter.SelectCommand.Connection = this.factory.CreateConnection();
                    adapter.SelectCommand.Connection.ConnectionString = connectionString;
                }
                adapter.SelectCommand.Connection.Open();
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(dt);
            }
            catch (InvalidOperationException ioe)
            {
                Logger.Instance.Log(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.SelectCommand));
                }
                else
                {
                    Logger.Instance.Log(dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Logger.Instance.Log(nulle);
            }
            catch (SystemException syse)
            {
                Logger.Instance.Log(syse);
            }
            finally
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection != null &&
                    adapter.SelectCommand.Connection.State == System.Data.ConnectionState.Open)
                {
                    adapter.SelectCommand.Connection.Close();
                }
            }
            return result;
        }

        public int DbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            return this.DbDataAdapterFill(this.connString, adapter, dt);
        }

        public int DbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            int result = -1;
            try
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection == null)
                {
                    adapter.SelectCommand.Connection = this.factory.CreateConnection();
                    adapter.SelectCommand.Connection.ConnectionString = connectionString;
                }
                adapter.SelectCommand.CommandTimeout = 0;
                adapter.SelectCommand.Connection.Open();
                result = adapter.Fill(ds);
            }
            catch (InvalidOperationException ioe)
            {
                Logger.Instance.Log(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.SelectCommand));
                }
                else
                {
                    Logger.Instance.Log(dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Logger.Instance.Log(nulle);
            }
            catch (SystemException syse)
            {
                Logger.Instance.Log(syse);
            }
            finally
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection != null &&
                    adapter.SelectCommand.Connection.State == System.Data.ConnectionState.Open)
                {
                    adapter.SelectCommand.Connection.Close();
                }
            }
            return result;
        }

        public int DbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            return this.DbDataAdapterFill(this.connString, adapter, ds);
        }
        #endregion

        #region DbDataAdapter.Update()
        /// <summary>
        /// DbDataAdapter.Update(DataTable)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            int result = -1;
            try
            {
                conn.ConnectionString = connectionString;
                if (adapter.SelectCommand != null)
                {
                    adapter.SelectCommand.Connection = conn;
                    adapter.SelectCommand.CommandTimeout = 0;
                }
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = conn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = conn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = conn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                conn.Open();
                result = adapter.Update(dt);
            }
            catch (InvalidOperationException ioe)
            {
                Logger.Instance.Log(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.SelectCommand));
                }
                if (adapter.UpdateCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.UpdateCommand));
                }
                if (adapter.InsertCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.InsertCommand));
                }
                if (adapter.DeleteCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.DeleteCommand));
                }
            }
            catch (ArgumentNullException nulle)
            {
                Logger.Instance.Log(nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                Logger.Instance.Log(dbe);
            }
            catch (SystemException syse)
            {
                Logger.Instance.Log(syse);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        public int DbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            return this.DbDataAdapterUpdate(this.connString, adapter, dt);
        }
        /// <summary>
        /// DbDataAdapter.Update(DataSet)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            int result = -1;
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                if (adapter.SelectCommand != null)
                {
                    adapter.SelectCommand.Connection = conn;
                    adapter.SelectCommand.CommandTimeout = 0;
                }
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = conn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = conn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = conn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                conn.Open();
                result = adapter.Update(ds);
            }
            catch (InvalidOperationException ioe)
            {
                Logger.Instance.Log(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.SelectCommand));
                }
                if (adapter.UpdateCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.UpdateCommand));
                }
                if (adapter.InsertCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.InsertCommand));
                }
                if (adapter.DeleteCommand != null)
                {
                    Logger.Instance.Log(dbe, this.GetCommandDetail(adapter.DeleteCommand));
                }
            }
            catch (ArgumentNullException nulle)
            {
                Logger.Instance.Log(nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                Logger.Instance.Log(dbe);
            }
            catch (SystemException syse)
            {
                Logger.Instance.Log(syse);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        public int DbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            return this.DbDataAdapterUpdate(this.connString, adapter, ds);
        }
        #endregion


        public System.Data.Common.DbCommandBuilder CreateCommandBuilder()
        {
            return this.factory.CreateCommandBuilder();
        }

        public System.Data.Common.DbCommandBuilder CreateCommandBuilder(System.Data.Common.DbDataAdapter dbDataAdapter)
        {
            if (dbDataAdapter is System.Data.SqlClient.SqlDataAdapter)
            {
                return new System.Data.SqlClient.SqlCommandBuilder(dbDataAdapter as System.Data.SqlClient.SqlDataAdapter);
            }
            else if (dbDataAdapter is System.Data.OleDb.OleDbDataAdapter)
            {
                return new System.Data.OleDb.OleDbCommandBuilder(dbDataAdapter as System.Data.OleDb.OleDbDataAdapter);
            }
            else
            {
                return this.factory.CreateCommandBuilder();
            }
        }
        #endregion
        #endregion
    }

}
