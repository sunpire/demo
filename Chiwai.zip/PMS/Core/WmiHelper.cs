﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;
using System.Diagnostics;

namespace PMS.Core
{
    public class WmiHelper
    {
        public const string ManagementScopePath = @"\\{0}\root\cimv2";
        public const string ServerTimeQuery = "select * from win32_localtime";

        private static object syncRoot = new Object();

        /// <summary>
        /// Machine, Time Diff, Logged time
        /// </summary>
        private static Dictionary<string, Tuple<TimeSpan, DateTime>> ServerTimeDiffs;

        static WmiHelper()
        {
            ServerTimeDiffs = new Dictionary<string, Tuple<TimeSpan, DateTime>>();
        }

        /// <summary>
        /// Gets the local time on a remote machine
        /// </summary>
        /// <param name="site">Server to get time from</param>
        /// <returns>Local time of server</returns>
        public static DateTime GetRemoteMachineTime(string machine)
        {
            DateTime time = new DateTime();
            using (ManagementObjectCollection collection = GetManagementObjectCollection(machine, new ObjectQuery(ServerTimeQuery)))
            {
                if (collection != null)
                {
                    foreach (ManagementObject obj in collection)
                    {
                        time = GetDateTimeFromObject(obj);
                        break;
                    }
                }
            }
            return time;
        }

        /// <summary>
        /// Notes: Its accuracy is millisecond
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private static DateTime GetDateTimeFromObject(ManagementObject obj)
        {
            foreach (var p in obj.Properties)
            {
                var v = obj.Properties[p.Name];
            }

            return new DateTime(Convert.ToInt32(obj["Year"]),
                                    Convert.ToInt32(obj["Month"]),
                                    Convert.ToInt32(obj["Day"]),
                                    Convert.ToInt32(obj["Hour"]),
                                    Convert.ToInt32(obj["Minute"]),
                                    Convert.ToInt32(obj["Second"]),
                                    Convert.ToInt32(obj["Milliseconds"]));
        }

        /// <summary>
        /// Notes: Its accuracy is millisecond
        /// </summary>
        /// <param name="machine"></param>
        /// <returns></returns>
        public static TimeSpan GetRemoteMachineTimeDiff(string machine)
        {
            lock (syncRoot)
            {
                string m = machine.ToUpper();
                if (!(ServerTimeDiffs.ContainsKey(m) && (DateTime.Now - ServerTimeDiffs[m].Item2).TotalHours < 24))
                {
                    DateTime nowLocal = DateTime.Now;
                    Stopwatch stopWatch = Stopwatch.StartNew();
                    DateTime nowServer = GetRemoteMachineTime(m);
                    stopWatch.Stop();
                    //it takes time to get the server time so we need to take that difference into account
                    TimeSpan diff = nowServer.Subtract(stopWatch.Elapsed).Subtract(nowLocal);
                    if (ServerTimeDiffs.ContainsKey(m))
                    {
                        ServerTimeDiffs[m] = new Tuple<TimeSpan, DateTime>(diff, nowLocal);
                    }
                    else
                    {
                        ServerTimeDiffs.Add(m, new Tuple<TimeSpan, DateTime>(diff, nowLocal));
                    }
                }
                return ServerTimeDiffs[m].Item1;
            }
        }

        /// <summary>
        /// Get these fields for a EventLog entry: EventType, Type, SourceName, Category, EventCode, TimeGenerated, Message.
        /// </summary>
        /// <param name="machine"></param>
        /// <param name="logFile"></param>
        /// <param name="type"></param>
        /// <param name="source"></param>
        /// <param name="category"></param>
        /// <param name="eventCode"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns>The returned entries are not well sorted by TimeGenerated, please copy them to a local array for further uses</returns>
        public static ManagementObjectCollection GetRemoteEvents(string machine, string logFile, EventLogEntryType type, string source, string category, string eventCode, DateTime? startTime, DateTime? endTime)
        {
            StringBuilder sb = new StringBuilder(string.Format("Select EventType, Type, SourceName, Category, EventCode, TimeGenerated, Message From Win32_NTLogEvent Where Logfile='{0}' And ", logFile));
            sb.Append(BuildQueryFilter("EventType", EventTypeToValueString(type), true));
            if (!string.IsNullOrEmpty(source))
            {
                sb.AppendFormat(" And {0}", BuildQueryFilter("SourceName", source, false));
            }
            if (!string.IsNullOrEmpty(category))
            {
                sb.AppendFormat(" And {0}", BuildQueryFilter("Category", category, false));
            }
            if (!string.IsNullOrEmpty(eventCode))
            {
                sb.AppendFormat(" And {0}", BuildQueryFilter("EventCode", eventCode, true));
            }
            if (startTime.HasValue)
            {
                sb.AppendFormat(" And TimeGenerated>='{0}'", ManagementDateTimeConverter.ToDmtfDateTime(startTime.Value));
            }
            if (endTime.HasValue)
            {
                sb.AppendFormat(" And TimeGenerated<='{0}'", ManagementDateTimeConverter.ToDmtfDateTime(endTime.Value));
            }
            return GetManagementObjectCollection(machine, new ObjectQuery(sb.ToString()));
        }

        /// <summary>
        /// Get these fields for a EventLog entry: EventType, Type, SourceName, Category, EventCode, TimeGenerated, Message.
        /// Sorted as from oldest to latest
        /// </summary>
        /// <param name="machine"></param>
        /// <param name="logFile"></param>
        /// <param name="type"></param>
        /// <param name="source"></param>
        /// <param name="category"></param>
        /// <param name="eventCode"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns>From oldest to latest</returns>
        public static ManagementObject[] GetSortedRemoteEvents(string machine, string logFile, EventLogEntryType type, string source, string category, string eventCode, DateTime? startTime, DateTime? endTime)
        {
            try
            {
                ManagementObjectCollection coll = GetRemoteEvents(machine, logFile, type, source, category, eventCode, startTime, endTime);
                if (coll == null || coll.Count == 0)
                {
                    return new ManagementObject[0];
                }
                ManagementObject[] entries = new ManagementObject[coll.Count];
                coll.CopyTo(entries, 0);
                return entries.OrderBy(e => e.Properties["TimeGenerated"].Value).ToArray();
            }
            catch (System.Management.ManagementException ex)
            {
                //if (ex.Message.StartsWith("Quota violation"))
                //{
                //    throw ex;
                //}
                throw ex;
            }
        }

        #region EventLog Helper
        private static string[] EventTypeToValueString(EventLogEntryType type)
        {
            List<string> typeFilters = new List<string>();
            if (type.HasFlag(EventLogEntryType.Error))
            {
                typeFilters.Add(((byte)EventLogEntryType.Error).ToString());
            }
            if (type.HasFlag(EventLogEntryType.Warning))
            {
                typeFilters.Add(((byte)EventLogEntryType.Warning).ToString());
            }
            if (type.HasFlag(EventLogEntryType.Information))
            {
                // It is 3 but not 4
                typeFilters.Add("3");
            }
            return typeFilters.ToArray();
        }

        private static string[] EventTypeToNameString(EventLogEntryType type)
        {
            List<string> typeFilters = new List<string>();
            if (type.HasFlag(EventLogEntryType.Error))
            {
                typeFilters.Add("Error");
            }
            if (type.HasFlag(EventLogEntryType.Warning))
            {
                typeFilters.Add("Warning");
            }
            if (type.HasFlag(EventLogEntryType.Information))
            {
                typeFilters.Add("Information");
            }
            return typeFilters.ToArray();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterFieldName"></param>
        /// <param name="filterValue">Delimter is |</param>
        /// <param name="isNumber"></param>
        /// <returns></returns>
        private static string BuildQueryFilter(string filterFieldName, string filterValue, bool isNumber)
        {
            return BuildQueryFilter( filterFieldName, 
                                        filterValue.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries),
                                        isNumber);
        }

        private static string BuildQueryFilter(string filterFieldName, string[] values, bool isNumber)
        {
            List<string> filters = new List<string>(values.Length);
            foreach (string value in values)
            {
                if (isNumber)
                {
                    filters.Add(string.Format("{0}={1}", filterFieldName, value));
                }
                else
                {
                    filters.Add(string.Format("{0}='{1}'", filterFieldName, value));
                }
            }
            if (values.Length > 1)
            {
                return string.Format("({0})", string.Join(" Or ", filters));
            }
            else
            {
                return filters[0];
            }
        }
        #endregion

        private static ManagementObjectCollection GetManagementObjectCollection(string machine, ObjectQuery query)
        {
            ManagementObjectCollection collection = null;
            ConnectionOptions connection = new ConnectionOptions();
            connection.Impersonation = ImpersonationLevel.Impersonate;
            ManagementScope scope = new ManagementScope(String.Format(ManagementScopePath, machine), connection);
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query))
                {
                    collection = searcher.Get();
                }
            }
            catch (System.UnauthorizedAccessException ex)
            {
                Logger.Instance.Log(ex, "The machine is {0}", machine);
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                //The RPC server is unavailable.
                Logger.Instance.Log(ex, "The machine is {0}", machine);
            }
            return collection;
        }
    }
}
