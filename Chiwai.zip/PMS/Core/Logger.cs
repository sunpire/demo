﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace PMS.Core
{
    public class Logger
    {
        #region Singleton
        private static volatile Logger instance;
        private static object syncRoot = new Object();
        public static Logger Instance
        {
            get
            {
                /// Double-Check Locking 
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                        {
                            instance = new Logger();
                        }
                    }
                }
                return instance;
            }
        }
        protected Logger()
        {

        }
        #endregion

        public void Log(string msg)
        {
            Debug.WriteLine("[{0:MM-dd HH:mm:ss:fff}]{1}", DateTime.Now, msg);
        }

        public void Log(string format, params object[] args)
        {
            Debug.WriteLine("[{0:MM-dd HH:mm:ss:fff}]{1}", DateTime.Now, string.Format(format, args));
        }

        public void Log(Exception ex, string msg)
        {
            Debug.WriteLine("[{0:MM-dd HH:mm:ss:fff}][Exception]{1}{2}Exception Details:{3}", DateTime.Now, msg, Environment.NewLine, ex);
        }

        public void Log(Exception ex, string format, params object[] args)
        {
            Debug.WriteLine("[{0:MM-dd HH:mm:ss:fff}][Exception]{1}{2}Exception Details:{3}", DateTime.Now, string.Format(format, args), Environment.NewLine, ex);
        }

        public void Log(Exception ex)
        {
            Debug.WriteLine("[{0:MM-dd HH:mm:ss:fff}][Exception]Exception Details:{1}", DateTime.Now, ex);
        }
    }
}
