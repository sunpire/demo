﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace PMS.Core
{
    #region Config
    [DataContract]
    public class PerformanceMonitorConfig
    {
        [DataMember(Order = 1)]
        public List<CounterConfig> BasicCounters { get; set; }

        /// <summary>
        /// Enabled BasicCounters, it will never be null
        /// </summary>
        public List<CounterConfig> EnabledBasicCounters
        {
            get
            {
                if (this.BasicCounters == null)
                {
                    return new List<CounterConfig>(0);
                }
                else
                {
                    return this.BasicCounters.Where(c => c.IsEnabled).ToList();
                }
            }
        }

        [DataMember(Order = 2)]
        public List<CounterConfig> AdvancedCounters { get; set; }

        /// <summary>
        /// Enabled AdvancedCounters, it will never be null
        /// </summary>
        public List<CounterConfig> EnabledAdvancedCounters
        {
            get
            {
                if (this.AdvancedCounters == null)
                {
                    return new List<CounterConfig>(0);
                }
                else
                {
                    return this.AdvancedCounters.Where(c => c.IsEnabled).ToList();
                }
            }
        }

        [DataMember(Order = 3, Name = "DefaultMachines")]
        public List<MachineEntry> Machines { get; set; }

        /// <summary>
        /// The max time(in seconds) to allow a PerformanceCounter keeps working since last time when the caller let the service know it's still alive
        /// </summary>
        [DataMember(Order = 4)]
        public int KeepAlive { get; set; }

        /// <summary>
        /// To log all the fetched values into trace logging stream or not
        /// </summary>
        [DataMember(Order = 5)]
        public bool LogFetchedValues { get; set; }

        /// <summary>
        /// To log debug messages into trace logging stream or not
        /// </summary>
        [DataMember(Order = 6)]
        public bool LogDebugMessage { get; set; }

        /// <summary>
        /// Db Connection
        /// </summary>
        [DataMember(Order = 7)]
        public string LogDbConnectionString { get; set; }
    }

    [KnownTypeAttribute(typeof(PerfMonCounterConfig))]
    [KnownTypeAttribute(typeof(EventLogCounterConfig))]
    [KnownTypeAttribute(typeof(SplunkCounterConfig))]
    [DataContract(Name = "Counter")]
    public abstract class CounterConfig
    {
        [DataMember(Order = 1)]
        public int Id { get; set; }

        [DataMember(Order = 2)]
        public string FriendlyName { get; set; }

        /// <summary>
        /// If true, the datatype for values of the related counter should be Long,
        /// otherwise, the datatype is Float
        /// </summary>
        [DataMember(Order = 3)]
        public bool IsInteger { get; set; }

        /// <summary>
        /// Runs every 'interval' seconds
        /// </summary>
        [DataMember(Order = 4)]
        public int Interval { get; set; }

        /// <summary>
        /// If false, no monitoring tasks will be created from this CounterConfig
        /// </summary>
        [DataMember(Order = 8)]
        public bool IsEnabled { get; set; }
    }

    [DataContract(Name = "PerfMonCounter")]
    public class PerfMonCounterConfig : CounterConfig
    {
        [DataMember(Order = 1)]
        public string Category { get; set; }

        [DataMember(Order = 2)]
        public string Name { get; set; }

        [DataMember(Order = 3)]
        public string Instance { get; set; }
    }

    [KnownTypeAttribute(typeof(EventLogCounterConfig))]
    [KnownTypeAttribute(typeof(SplunkCounterConfig))]
    [DataContract(Name = "AdvancedCounter")]
    public abstract class AdvancedCounterConfig : CounterConfig
    {
        /// <summary>
        /// Defer to start 'DeferringStart' seconds.
        /// In general, it should equal to 'Interval'.
        /// </summary>
        [DataMember(Order = 1)]
        public int? DeferringStart { get; set; }

        /// <summary>
        /// Defer to end 'DeferringEnd' seconds.
        /// In general, it should equal to 'Interval'.
        /// </summary>
        [DataMember(Order = 2)]
        public int? DeferringEnd { get; set; }
    }

    [DataContract(Name = "EventLogCounter")]
    public class EventLogCounterConfig : AdvancedCounterConfig
    {
        [DataMember(Order = 0)]
        public EventLogQueryMethodType QueryMethod { get; set; }

        /// <summary>
        /// Application, System, etc
        /// </summary>
        [DataMember(Order = 1)]
        public string LogName { get; set; }

        /// <summary>
        /// EventLogEntryType, supports delimiter '|', Information|Error is valid.
        /// </summary>
        [DataMember(Order = 2)]
        public string EntryType { get; set; }

        [DataMember(Order = 3)]
        public string Source { get; set; }

        [DataMember(Order = 4)]
        public string Category { get; set; }

        [DataMember(Order = 5)]
        public int? EventCode { get; set; }

        [DataMember(Order = 11)]
        public EventLogEntryFilterType FilterType { get; set; }

        [DataMember(Order = 12)]
        public EventLogEntryAggregationType GroupType { get; set; }

        /// <summary>
        /// The same meaning as 'timespan' in Splunk query.
        /// It needs to divide the filtered out EventLog entries into groups by timespan
        /// </summary>
        [DataMember(Order = 13)]
        public int TimeScale { get; set; }

        [DataMember(Order = 14)]
        public string FilteredBy { get; set; }

        [DataMember(Order = 15)]
        public string GroupBy { get; set; }

        /// <summary>
        /// E.g., 'GroupBy EventCode' may lead to groups EventCode1, EventCode2, EventCode3... to be outputted
        /// </summary>
        [DataMember(Order = 16)]
        public bool UseGroupValueToFormFriendlyName { get; set; }
    }

    [DataContract(Name = "SplunkCounter")]
    public class SplunkCounterConfig : AdvancedCounterConfig
    {
        /// <summary>
        /// A Splunk query text
        /// </summary>
        [DataMember(Order = 1)]
        public string Query { get; set; }

    }


    [DataContract(Name = "Machine")]
    public class MachineEntry
    {
        [DataMember(Order = 1)]
        public string MachineName { get; set; }

        [DataMember(Order = 2)]
        public MonitoringType MonitoringType { get; set; }
    }

    #endregion

}
