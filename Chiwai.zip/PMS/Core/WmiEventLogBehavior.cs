﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Management;

namespace PMS.Core
{
    #region Second Edition for WmiEventLogBehavior
    /// <summary>
    /// Second Edition for WmiEventLogBehavior:
    /// In this edition, it querys WMI one time for each TimeScale, so that it doesn't need to sort the returns entries
    /// </summary>
    internal abstract class WmiEventLogBehavior : BaseEventLogBehavior
    {
        public override int Perform(string machine, EventLogCounter counter, List<AdvancedTaskRequest> requests)
        {
            this.IsPerforming = true;
            EventLogResult result = new EventLogResult(counter, requests);
            // Don't use Parallel.ForEach here since we don't want to concurrently query Wmi
            for (int i = result.RequestResults.Count - 1; i >= 0; i--)
            {
                EventLogRequestResult reqResult = result.RequestResults[i];
                AdvancedTaskRequest request = reqResult.Request;
                try
                {
                    int count = 0;
                    ManagementObjectCollection collection = GetEventCollection(machine, counter, request, out count);

                    if (collection == null || count == 0)
                    {
                        continue;
                    }

                    // Check Quickly Aggregate
                    if (this.QuicklyAggregate(collection, count, counter, ref reqResult))
                    {
                        continue;
                    }
                    else
                    {
                        // Can't do quick aggregation, needs to loop
                        this.FilterAndAggregate(collection, count, counter, ref reqResult);
                    }
                }
                catch (Exception ex)
                {
                    this.Log(ex, "Performing on timerange [{0} to {1}] for {2} on {3}", request.Start, request.End, counter, machine);
                }
            }
            this.FixAggregation(ref result);
            int storedCount = this.Store(counter.IsInteger, result);
            this.Log("Stored {0} rows into Db met timerange [{1} to {2}] for {3} on {4}", storedCount, result.RequestResults[result.RequestResults.Count - 1].Request.Start, result.RequestResults[0].Request.End, counter, machine);
            this.IsPerforming = false;
            return storedCount;
        }

        private ManagementObjectCollection GetEventCollection(string machine, EventLogCounter counter, AdvancedTaskRequest request, out int count)
        {
            this.Log("Filtering ManagementObject met timerange [{0} to {1}] for {2} on {3} via Wmi", request.Start, request.End, counter, machine);
            count = 0;
            byte triedTimes = 0, retryLimit = 3;
            ManagementObjectCollection collection = null;
            while (triedTimes < retryLimit)
            {
                try
                {
                    collection = WmiHelper.GetRemoteEvents(machine,
                                                            counter.LogName,
                                                            counter.EntryType,
                                                            counter.Source,
                                                            counter.Category,
                                                            counter.EventCode.HasValue ? counter.EventCode.Value.ToString() : string.Empty,
                                                            request.Start,
                                                            request.End);
                    if (collection != null)
                    {
                        // It might throw System.Management.ManagementException: Quota violation
                        count = collection.Count;
                    }
                    break;
                }
                catch (System.Management.ManagementException ex)
                {
                    if (ex.Message.StartsWith("Quota violation"))
                    {
                        triedTimes++;
                        if (triedTimes < retryLimit)
                        {
                            this.LogErrorMessage("Quota violation for timerange [{0} to {1}] for {2} on {3}, retry in {4} seconds", request.Start, request.End, counter, machine, triedTimes * 2);
                            System.Threading.Thread.Sleep(2000 * triedTimes);
                        }
                    }
                }
            }
            if (triedTimes < retryLimit)
            {
                this.Log("Filtered {4} ManagementObjects met timerange [{0} to {1}] for {2} on {3} via Wmi", request.Start, request.End, counter, machine, count);
            }
            else
            {
                // Still met Quota violation, in fact, we still can loop a portion of collection
                this.LogErrorMessage("Aborted due to Quota violation for timerange [{0} to {1}] for {2} on {3} after {4} attempts", request.Start, request.End, counter, machine, triedTimes);
            }
            return collection;
        }

        /// <summary>
        /// For 'Count All' case, it doesn't need to do any aggregation
        /// </summary>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <param name="counter"></param>
        /// <param name="reqResult"></param>
        /// <returns></returns>
        protected virtual bool QuicklyAggregate(ManagementObjectCollection collection, int count, EventLogCounter counter, ref EventLogRequestResult reqResult)
        {
            return false;
        }
        
        /// <summary>
        /// Filter out and do aggregation for the desired entries
        /// </summary>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <param name="counter"></param>
        /// <param name="reqResult"></param>
        protected virtual void FilterAndAggregate(ManagementObjectCollection collection, int count, EventLogCounter counter, ref EventLogRequestResult reqResult)
        {
            foreach(ManagementObject entry in collection)
            {
                if (!this.ApplyFilter(counter, entry))
                {
                    continue;
                }

                this.Aggregate(ref reqResult,
                                this.GenerateCounterKey(counter, entry),
                                this.ExtractValue(counter, entry));
            } 
        }

        /// <summary>
        /// Wmi has applied most of filters while querying, so here only filters Message(Description)
        /// </summary>
        /// <param name="counter"></param>
        /// <param name="entry"></param>
        /// <returns></returns>
        protected virtual bool ApplyFilter(EventLogCounter counter, ManagementObject entry)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                return Regex.IsMatch((string)(entry.Properties["Message"].Value), counter.FilteredBy, RegexOptions.Compiled);
            }

            return true;
        }

        protected virtual float ExtractValue(EventLogCounter counter, ManagementObject entry)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                Match m = Regex.Match((string)(entry.Properties["Message"].Value), counter.FilteredBy, RegexOptions.Compiled);
                if (m.Success)
                {
                    float value;
                    if (float.TryParse(m.Groups["Value"].Value, out value))
                    {
                        return value;
                    }
                }
            }
            return 0;
        }

        protected virtual void Aggregate(ref EventLogRequestResult reqResult, string key, float value)
        {
        }

        /// <summary>
        /// Just for Average Aggregation
        /// </summary>
        /// <param name="result"></param>
        protected virtual void FixAggregation(ref EventLogResult result)
        {
        }

        protected virtual string GenerateCounterKey(EventLogCounter counter, ManagementObject entry)
        {
            if (!(counter.GroupType != EventLogEntryAggregationType.None && counter.UseGroupValueToFormFriendlyName))
            {
                return counter.SafeCounterKey;
            }
            if (string.IsNullOrEmpty(counter.GroupBy))
            {
                return counter.SafeCounterKey;
            }
            string finalKey = counter.CounterKey;
            string[] groupBys = counter.GroupBy.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string grp in groupBys)
            {
                if (string.Equals(grp, "Source", StringComparison.CurrentCultureIgnoreCase))
                {
                    finalKey = this.CombineToSafeCounterKey(finalKey, (string)entry.Properties["SourceName"].Value);
                }
                else if (string.Equals(grp, "EventCode", StringComparison.CurrentCultureIgnoreCase))
                {
                    finalKey = this.CombineToSafeCounterKey(finalKey, entry.Properties["EventCode"].Value.ToString());
                }
            }
            return finalKey;
        }

    }
    #endregion

    #region Derived Classes
    internal class WmiCountEventLogBehavior : WmiEventLogBehavior
    {
        protected override bool QuicklyAggregate(ManagementObjectCollection collection, int count, EventLogCounter counter, ref EventLogRequestResult reqResult)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                return false;
            }
            if (counter.UseGroupValueToFormFriendlyName && !string.IsNullOrEmpty(counter.GroupBy))
            {
                return false;
            }
            reqResult.GroupResults.Add(counter.SafeCounterKey, new EventLogResultValue() { Count = count, Value = count });
            return true;
        }


        protected override void Aggregate(ref EventLogRequestResult reqResult, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = reqResult.GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                dict[key].Value++;
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = 1 });
            }
        }

        protected override float ExtractValue(EventLogCounter counter, ManagementObject entry)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                Match m = Regex.Match((string)(entry.Properties["Message"].Value), counter.FilteredBy, RegexOptions.Compiled);
                if (m.Success)
                {
                    float value;
                    if (float.TryParse(m.Groups["Value"].Value, out value))
                    {
                        return value;
                    }
                }
            }
            return 1;
        }
    }

    internal class WmiAverageEventLogBehavior : WmiEventLogBehavior
    {
        protected override void Aggregate(ref EventLogRequestResult reqResult, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = reqResult.GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                dict[key].Value += value;
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }

        protected override void FixAggregation(ref EventLogResult result)
        {
            foreach (EventLogRequestResult reqResult in result.RequestResults)
            {
                foreach (EventLogResultValue value in reqResult.GroupResults.Values)
                {
                    value.Value = value.Value / value.Count;
                }
            }
        }
    }

    internal class WmiMaxEventLogBehavior : WmiEventLogBehavior
    {
        protected override void Aggregate(ref EventLogRequestResult reqResult, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = reqResult.GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                if (dict[key].Value < value)
                {
                    dict[key].Value = value;
                }
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }
    }

    internal class WmiMinEventLogBehavior : WmiEventLogBehavior
    {
        protected override void Aggregate(ref EventLogRequestResult reqResult, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = reqResult.GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                if (dict[key].Value > value)
                {
                    dict[key].Value = value;
                }
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }
    }
    #endregion
}
