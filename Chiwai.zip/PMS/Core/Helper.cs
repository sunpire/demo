﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMS.Core
{
    public class Helper
    {
        private static string executingDirectory = string.Empty;

        public static string ExecutingDirectory
        {
            get
            {
                if (string.IsNullOrEmpty(executingDirectory))
                {
                    try
                    {
                        executingDirectory = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetCallingAssembly().CodeBase);
                    }
                    catch (System.IO.PathTooLongException)
                    {
                        //Framework.ExceptionHandler.Handle(e);
                    }
                    catch (System.ArgumentException)
                    {
                        //Framework.ExceptionHandler.Handle(e);
                    }
                }
                return executingDirectory;
            }
        }

        public static bool CanResolveMachineName(string machine)
        {
            try
            {
                System.Net.Dns.GetHostEntry(machine);
                return true;
            }
            catch (System.Net.Sockets.SocketException)
            {
            }
            catch (System.ArgumentNullException)
            {
            }
            catch (System.ArgumentException)
            {
            }
            return false;
        }

        public static string DataContractSerialize<T>(T target) where T : class
        {
            string result = string.Empty;
            try
            {
                System.Runtime.Serialization.DataContractSerializer dcs = new System.Runtime.Serialization.DataContractSerializer(typeof(T));
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    dcs.WriteObject(ms, target);
                    ms.Seek(0, System.IO.SeekOrigin.Begin);
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(ms))
                    {
                        result = reader.ReadToEnd();
                    }
                }
            }
            catch (System.Runtime.Serialization.InvalidDataContractException ex)
            {
                Logger.Instance.Log(ex, "DataContractSerialize");
            }
            catch (System.Runtime.Serialization.SerializationException ex)
            {
                Logger.Instance.Log(ex, "DataContractSerialize");
            }
            catch (Exception ex)
            {
                Logger.Instance.Log(ex, "DataContractSerialize");
            }
            return result;
        }

        public static T DataContractDeserialize<T>(string serializedValue) where T : class
        {
            T destination = null;
            try
            {
                System.Runtime.Serialization.DataContractSerializer dcs = new System.Runtime.Serialization.DataContractSerializer(typeof(T));
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes(serializedValue)))
                {
                    destination = dcs.ReadObject(ms) as T;
                }
            }
            catch (System.Exception ex)
            {
                Logger.Instance.Log(ex, "DataContractDeserialize");
            }
            return destination;
        }

        /// <summary>
        /// Clone using Data Contract
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <returns></returns>
        public static T DataContractCopy<T>(T target) where T : class
        {
            return DataContractDeserialize<T>(DataContractSerialize<T>(target));
        }

        public static string LoadTextFile(string filePath)
        {
            try
            {
                string file = filePath;
                if (filePath.StartsWith("file:\\"))
                {
                    file = file.Substring("file:\\".Length);
                }
                using (System.IO.FileStream fs = new System.IO.FileStream(file, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite))
                {
                    fs.Seek(0, System.IO.SeekOrigin.Begin);
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(fs, Encoding.UTF8))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Log(ex, "LoadTextFile");
            }
            return null;
        }
    }
}
