﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Runtime.Serialization;

namespace PMS.Core
{
    [DataContract]
    public class BasicTask : Task
    {
        public Queue<Data> Buffer { get; protected set; }

        private PerfMonCounter ThePerfCounter
        {
            get
            {
                return (PerfMonCounter)this.Instance.TheCounter;
            }
        }

        private PerformanceCounter pc;

        internal BasicTask(string machine, string category, string counter, string instance, int interval)
            : this(machine, new PerfMonCounter(category, counter, instance), interval)
        {            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="machine"></param>
        /// <param name="counter"></param>
        /// <param name="interval">interval seconds</param>
        internal BasicTask(string machine, PerfMonCounter counter, int interval)
        {
            this.Instance = new CounterInstance(machine, counter);
            this.bufferSize = 300 / interval;
            this.Interval = interval;
            if (this.bufferSize < 1)
            {
                this.bufferSize = 2;
            }
            this.Buffer = new Queue<Data>();
        }

        /// <summary>
        /// Uses ThreadPool to initialize PerformanceCounter
        /// </summary>
        /// <param name="runId">if specified, run after initializing</param>
        /// <param name="interval">interval for running</param>
        internal override void CreateCounter(long? runId = null, int? interval = null)
        {
            if (this.HasCreated && !this.HasFaulted)
            {
                return;
            }

            // if "new PerformanceCounter()" takes long time, it may run into concurrent risk
            bool unsafeConcurrentCreating = false;
            if (this.IsCreating)
            {
                if ((runId.HasValue && this.RunIdInCreating.HasValue && runId.Value != this.RunIdInCreating.Value) ||
                    (runId.HasValue && !this.RunIdInCreating.HasValue) ||
                    (!runId.HasValue && this.RunIdInCreating.HasValue))
                {
                    this.OnLogged(string.Format("RunId changed form {0} to {1} while PerfMonCounter is still Initializing", this.RunIdInCreating, runId));
                    unsafeConcurrentCreating = true;
                }
            }

            this.RunIdInCreating = runId;
            this.intervalInCreating = interval;
            if (unsafeConcurrentCreating)
            {
                return;
            }
            this.IsCreating = true;
            ThreadPool.QueueUserWorkItem((arg) => {
                try
                {
                    this.OnLogged(string.Format("PerfMonCounter Initializing"));
                    // It may need to take a long time
                    this.pc = new PerformanceCounter(this.ThePerfCounter.Category, this.ThePerfCounter.Name, this.ThePerfCounter.Instance, this.Instance.Machine);
                    this.pc.ReadOnly = true;
                    this.HasCreated = true;
                    this.HasFaulted = false;
                    this.OnLogged(string.Format("PerfMonCounter Initialized"));
                    this.toKill = false;
                    this.Instance.Started = null;
                    this.Instance.LastFetched = null;
                    this.Instance.LastHeartBeat = null;
                    if (this.RunIdInCreating.HasValue && this.intervalInCreating.HasValue)
                    {
                        this.Start(this.RunIdInCreating.Value, this.intervalInCreating.Value);
                        this.RunIdInCreating = null;
                        this.intervalInCreating = null;
                    }
                    this.Run();
                }
                catch (InvalidOperationException ex)
                {
                    // PerfMonCounter does not exist or others
                    this.OnExceptionOccurred(ex);
                    this.FaultCounter();
                }
                catch (ArgumentException ex)
                {
                    this.OnExceptionOccurred(ex);
                    this.KillCounter();
                }
                catch (UnauthorizedAccessException ex)
                {
                    this.OnExceptionOccurred(ex);
                    this.KillCounter();
                }
                // Network path doesn't exist
                catch (System.ComponentModel.Win32Exception ex)
                {
                    this.OnExceptionOccurred(ex);
                    this.KillCounter();
                }
                this.IsCreating = false;
            });
        }

        private void Run()
        {
            this.timer = new Timer(new TimerCallback(TimerRun), null, 0, this.Interval * 1000);
        }

        private void TimerRun(object state)
        {
            try
            {
                if (!this.toKill)
                {
                    float value = this.pc.NextValue();

                    Data d = new Data()
                    {
                        LoggedTime = DateTime.Now,
                        Value = value
                    };
                    this.Instance.LastFetched = DateTime.Now;
                    if (this.Instance.IsRunning)
                    {
                        if (LogFetchedValues)
                        {
                            this.OnDataFectched(this.Instance, d);
                        }
                        DbLogger.Instance.EnqueueToLogToDb(this.Instance, d);
                    }
                    else
                    {
                        if (this.Buffer.Count == this.bufferSize)
                        {
                            this.Buffer.Dequeue();
                        }
                        this.Buffer.Enqueue(d);
                        if (LogFetchedValues)
                        {
                            this.OnLogged(string.Format("{0}(To buffer)", value));
                        }
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                this.OnExceptionOccurred(ex);
                this.FaultCounter();
            }
            catch (ArgumentException ex)
            {
                this.OnExceptionOccurred(ex);
                this.KillCounter();
            }
            catch (UnauthorizedAccessException ex)
            {
                this.OnExceptionOccurred(ex);
                this.KillCounter();
            }
            catch (System.Threading.ThreadAbortException)
            {
                //Thread was being aborted
            }
            catch (Exception ex)
            {
                this.OnExceptionOccurred(ex);
                this.KillCounter();
            }
        }

        /// <summary>
        /// Start and set interval
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="interval"></param>
        internal override void Start(long runId, int interval)
        {
            this.Instance.RunId = runId;
            this.Instance.Started = DateTime.Now;
            this.HeartBeat();
            this.ChangeInterval(interval);
            this.OnLogged("PerfMonCounter Started");
            this.SaveBufferToDb();
        }

        private void SaveBufferToDb()
        {
            while (this.Buffer.Count > 0)
            {
                Data d = this.Buffer.Dequeue();
                if (d != null)
                {
                    if (LogFetchedValues)
                    {
                        this.OnLogged(string.Format("{0}(From buffer {1:mm:ss:fff})", d.Value, d.LoggedTime));
                    }
                    if (d.LoggedTime >= this.Instance.Started.Value.AddSeconds(-30))
                    {
                        DbLogger.Instance.EnqueueToLogToDb(this.Instance, d);
                    }
                }
            }
        }

        private bool CleanRunIdIfInitializationNotFinished()
        {
            if (!this.HasCreated)
            {
                this.RunIdInCreating = null;
                this.intervalInCreating = null;
                return true;
            }
            return false;
        }

        internal override void Pause(int interval, bool dueToCallerDead = false)
        {
            bool initializationNotFinished = this.CleanRunIdIfInitializationNotFinished();
            this.Instance.RunId = null;
            this.ChangeInterval(interval);
            if (dueToCallerDead)
            {
                this.OnLogged("PerfMonCounter Turned to Standby due to the caller doesn't contact anymore");
            }
            else
            {
                if (!initializationNotFinished)
                {
                    this.OnLogged("PerfMonCounter Turned to Standby");
                }
                else
                {
                    this.OnLogged("PerfMonCounter was asked to turned to Standby while it is still in initializing");
                }
            }
        }

        internal override void FaultCounter()
        {
            this.CleanRunIdIfInitializationNotFinished();
            this.toKill = true;
            // Keeps the RunId
            if (this.HasCreated)
            {
                if (this.timer != null)
                {
                    this.timer.Dispose();
                    this.timer = null;
                }
                if (this.pc != null)
                {
                    this.pc.Close();
                    this.pc.Dispose();
                    this.pc = null;
                }
            }
            this.HasFaulted = true;
            this.OnLogged("PerfMonCounter Faulted");
        }

        internal override void KillCounter(bool dueToCallerDead = false)
        {
            bool initializationNotFinished = this.CleanRunIdIfInitializationNotFinished();
            this.toKill = true;
            this.Instance.RunId = null;
            this.Instance.Started = null;
            this.Instance.LastFetched = null;
            this.Instance.LastHeartBeat = null;
            if (this.HasCreated)
            {
                if (this.timer != null)
                {
                    this.timer.Dispose();
                    this.timer = null;
                }
                if (this.pc != null)
                {
                    this.pc.Close();
                    this.pc.Dispose();
                    this.pc = null;
                }
                this.HasCreated = false;
                if (dueToCallerDead)
                {
                    this.OnLogged("PerfMonCounter Killed due to the caller doesn't contact anymore");
                }
                else
                {                    
                    if (!initializationNotFinished)
                    {
                        this.OnLogged("PerfMonCounter Killed");
                    }
                    else
                    {
                        this.OnLogged("PerfMonCounter was to be killed while it is still in initializing");
                    }
                }
            }
        }

    }
}
