﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMS.Core
{
    public class CouterFactory
    {
        public static Counter FromConfig(CounterConfig cc)
        {
            if( cc is PerfMonCounterConfig)
            {
                return PerfMonCounter.FromConfig((PerfMonCounterConfig)cc);
            }
            else if (cc is EventLogCounterConfig)
            {
                return EventLogCounter.FromConfig((EventLogCounterConfig)cc);
            }
            else if (cc is SplunkCounterConfig)
            {
                return SplunkCounter.FromConfig((SplunkCounterConfig)cc);
            }
            return null;
        }
    }
}
