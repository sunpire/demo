﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMS.Core
{
    internal class EventLogResult
    {
        public EventLogEntryAggregationType AggregationType { get; set; }
        /// <summary>
        /// Ordered by time from latest to oldest
        /// </summary>
        public List<EventLogRequestResult> RequestResults { get; set; }

        /// <summary>
        /// Divide into TimeSpan groups ordered by time from latest to oldest
        /// </summary>
        /// <param name="counter"></param>
        /// <param name="requests"></param>
        /// <returns></returns>
        internal EventLogResult(EventLogCounter counter, List<AdvancedTaskRequest> requests)
        {
            this.AggregationType = counter.GroupType;
            this.RequestResults = new List<EventLogRequestResult>();

            // Divide into TimeSpan groups
            for (int i = requests.Count - 1; i >= 0; i--)
            {
                DateTime end = requests[i].End;
                DateTime start = requests[i].End.AddSeconds(-counter.TimeScale);
                if (start < requests[i].Start)
                {
                    start = requests[i].Start;
                }
                do
                {
                    this.RequestResults.Add(new EventLogRequestResult(requests[i].RunId, start, end));
                    end = end.AddSeconds(-counter.TimeScale);
                    start = start.AddSeconds(-counter.TimeScale);
                    if (start < requests[i].Start)
                    {
                        start = requests[i].Start;
                    }
                    if ((start - requests[i].Start).TotalSeconds <= 1)
                    {
                        start = requests[i].Start;
                    }
                }
                while ((end - start).TotalSeconds > 1);
            }
        }
    }

    internal class EventLogRequestResult
    {
        public AdvancedTaskRequest Request { get; set; }
        public Dictionary<string, EventLogResultValue> GroupResults { get; set; }

        internal EventLogRequestResult(long runId, DateTime start, DateTime end)
        {
            this.Request = new AdvancedTaskRequest(runId, start, end);
            this.GroupResults = new Dictionary<string, EventLogResultValue>();
        }
    }

    internal class EventLogResultValue
    {
        /// <summary>
        /// Only for Average counter
        /// </summary>
        public int Count { get; set; }

        public float Value { get; set; }
    }
}
