﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace PMS.Core
{
    internal abstract class EventLogBehavior : BaseEventLogBehavior
    {
        public override int Perform(string machine, EventLogCounter counter, List<AdvancedTaskRequest> requests)
        {
            this.IsPerforming = true;
            EventLog eventLog = new EventLog(counter.LogName, machine)
            {
                EnableRaisingEvents = false,
            };
            // IMPORTANT: make sure this.eventLog.Close() or entries.CopyTo() has been called
            EventLogEntryCollection entries = eventLog.Entries;
            eventLog.Close();

            EventLogResult result = new EventLogResult(counter, requests);
            try
            {
                this.Filter(entries, counter, ref result);
            }
            catch (Exception ex)
            {
                this.Log(ex, "Performing against {0} entries for {1}", entries.Count, counter);
            }
            return this.Store(counter, ref result);
        }

        private int Store(EventLogCounter counter, ref EventLogResult result)
        {
            this.FixAggregation(ref result);
            int count = this.Store(counter.IsInteger, result);
            this.Log("Stored {0} rows into Db met timerange [{1} to {2}] for {3}", count, result.RequestResults[result.RequestResults.Count - 1].Request.Start, result.RequestResults[0].Request.End, counter);
            this.IsPerforming = false;
            return count;
        }

        private EventLogEntry GetEntry(EventLogEntryCollection entries, ref int index, ref int lastEntriesCount)
        {
            while (true)
            {
                int currentEntriesCount = entries.Count;
                if (lastEntriesCount != currentEntriesCount)
                {
                    //this.Log("Entries.Count changed from {0} to {1} for {2}, current index is {3}", lastEntriesCount, entries.Count, counter, i);
                    index = index + (lastEntriesCount - currentEntriesCount);
                    lastEntriesCount = currentEntriesCount;
                }
                if (currentEntriesCount == entries.Count)
                {
                    if (index < currentEntriesCount)
                    {
                        // System.ArgumentException
                        return entries[index];
                    }
                    //else
                    //{
                    //    lastEntriesCount = entries.Count;
                    //    index = lastEntriesCount - 1;
                    //    return entries[index];
                    //}
                }
            }
        }

        /// <summary>
        /// Filter out and do aggregation
        /// </summary>
        /// <param name="entries"></param>
        /// <param name="counter"></param>
        /// <param name="result"></param>
        protected virtual void Filter(EventLogEntryCollection entries, EventLogCounter counter, ref EventLogResult result)
        {
            // dict.Keys are sorted by DateTime DESC, get the latest key.
            int requestIndex = 0;
            AdvancedTaskRequest request = result.RequestResults[0].Request;
            this.Log("Filtering EventLogEntry met timerange [{0} to {1}] for {2}", result.RequestResults[result.RequestResults.Count-1].Request.Start, request.End, counter);
            int lastEntriesCount = entries.Count;
            // entries are sorted by TimeWritten ASC, get the latest entry.
            for (int i = entries.Count - 1; i >= 0; i--)
            {
                EventLogEntry entry = this.GetEntry(entries, ref i, ref lastEntriesCount);

                // if entry.TimeWritten is between request.Start && request.End, goes through
                if (!(entry.TimeWritten >= request.Start && entry.TimeWritten <= request.End))
                {
                    // Later than the current key, try the next Eventlog entry
                    if (entry.TimeWritten > request.End)
                    {
                        continue;
                    }
                    // Then, met the first entry whose TimeWritten < request.End
                    while (entry.TimeWritten < request.End && entry.TimeWritten < request.Start && requestIndex < result.RequestResults.Count - 1)
                    {
                        request = result.RequestResults[++requestIndex].Request;
                    }
                    // Eariler than the earilest key, reach the end
                    if (entry.TimeWritten < request.Start && requestIndex == result.RequestResults.Count - 1)
                    {
                        break;
                    }
                }

                // Continue going through
                if (!this.ApplyFilter(counter, entry))
                {
                    continue;
                }

                this.Aggregate(ref result, 
                                requestIndex, 
                                this.GenerateCounterKey(counter, entry), 
                                this.ExtractValue(counter, entry));
            }// End of looping entries 
        }

        protected virtual bool ApplyFilter(EventLogCounter counter, EventLogEntry entry)
        {
            if (!counter.ConvertEntryType().HasFlag(entry.EntryType))
            {
                return false;
            }

            if (!string.IsNullOrEmpty(counter.Source))
            {
                if (!string.Equals(entry.Source, counter.Source, StringComparison.CurrentCultureIgnoreCase))
                {
                    return false;
                }
            }

            if (!string.IsNullOrEmpty(counter.Category))
            {
                if (!string.Equals(entry.Category, counter.Category, StringComparison.CurrentCultureIgnoreCase))
                {
                    return false;
                }
            }

            if (counter.EventCode.HasValue)
            {
                if (ToEventId(entry.InstanceId) != counter.EventCode.Value)
                {
                    return false;
                }
            }

            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                return Regex.IsMatch(entry.Message, counter.FilteredBy, RegexOptions.Compiled);
            }

            return true;
        }

        protected virtual float ExtractValue(EventLogCounter counter, EventLogEntry entry)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                Match m = Regex.Match(entry.Message, counter.FilteredBy, RegexOptions.Compiled);
                if (m.Success)
                {
                    float value;
                    if (float.TryParse(m.Groups["Value"].Value, out value))
                    {
                        return value;
                    }
                }
            }
            return 0;
        }
 
        protected virtual void Aggregate(ref EventLogResult result, int requestIndex, string key, float value)
        {
        }

        protected virtual void FixAggregation(ref EventLogResult result)
        {
        }

        protected virtual string GenerateCounterKey(EventLogCounter counter, EventLogEntry entry)
        {
            if (!(counter.GroupType != EventLogEntryAggregationType.None && counter.UseGroupValueToFormFriendlyName))
            {
                return counter.SafeCounterKey;
            }
            if (string.IsNullOrEmpty(counter.GroupBy))
            {
                return counter.SafeCounterKey;
            }
            string finalKey = counter.CounterKey;
            string[] groupBys = counter.GroupBy.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string grp in groupBys)
            {
                if (string.Equals(grp, "Source", StringComparison.CurrentCultureIgnoreCase))
                {
                    finalKey = this.CombineToSafeCounterKey(finalKey, entry.Source);
                }
                else if (string.Equals(grp, "EventCode", StringComparison.CurrentCultureIgnoreCase))
                {
                    finalKey = this.CombineToSafeCounterKey(finalKey, ToEventId(entry.InstanceId).ToString());
                }
            }
            return finalKey;
        }

        public static long ToEventId(long instanceId)
        {
            //65535 is 1111111111111111
            return instanceId & 65535;
        }

    }

    internal class CountEventLogBehavior : EventLogBehavior
    {
        protected override void Aggregate(ref EventLogResult result, int requestIndex, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = result.RequestResults[requestIndex].GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                dict[key].Value++;
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = 1 });
            }
        }

        protected override float ExtractValue(EventLogCounter counter, EventLogEntry entry)
        {
            if (counter.FilterType == EventLogEntryFilterType.FromDescription)
            {
                Match m = Regex.Match(entry.Message, counter.FilteredBy, RegexOptions.Compiled);
                if (m.Success)
                {
                    float value;
                    if (float.TryParse(m.Groups["Value"].Value, out value))
                    {
                        return value;
                    }
                }
            }
            return 1;
        }
    }

    internal class AverageEventLogBehavior : EventLogBehavior
    {
        protected override void Aggregate(ref EventLogResult result, int requestIndex, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = result.RequestResults[requestIndex].GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                dict[key].Value += value;
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }

        protected override void FixAggregation(ref EventLogResult result)
        {
            foreach (EventLogRequestResult reqResult in result.RequestResults)
            {
                foreach (EventLogResultValue value in reqResult.GroupResults.Values)
                {
                    value.Value = value.Value / value.Count;
                }
            }
        }
    }

    internal class MaxEventLogBehavior : EventLogBehavior
    {
        protected override void Aggregate(ref EventLogResult result, int requestIndex, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = result.RequestResults[requestIndex].GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                if (dict[key].Value < value)
                {
                    dict[key].Value = value;
                }
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }
    }

    internal class MinEventLogBehavior : EventLogBehavior
    {
        protected override void Aggregate(ref EventLogResult result, int requestIndex, string key, float value)
        {
            Dictionary<string, EventLogResultValue> dict = result.RequestResults[requestIndex].GroupResults;
            if (dict.ContainsKey(key))
            {
                dict[key].Count++;
                if (dict[key].Value > value)
                {
                    dict[key].Value = value;
                }
            }
            else
            {
                dict.Add(key, new EventLogResultValue() { Count = 1, Value = value });
            }
        }
    }
}
