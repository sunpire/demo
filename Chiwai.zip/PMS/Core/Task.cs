﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Runtime.Serialization;

namespace PMS.Core
{
    [KnownTypeAttribute(typeof(BasicTask))]
    [KnownTypeAttribute(typeof(AdvancedTask))]
    [KnownTypeAttribute(typeof(EventLogTask))]
    [DataContract]
    public abstract class Task
    {
        #region events
        protected void OnDataFectched(CounterInstance counterInstance, Data data)
        {
            Logger.Instance.Log("{0} for {1}", data, this);
        }
        protected void OnExceptionOccurred(Exception ex)
        {
            Logger.Instance.Log(ex, "{0} for {1}", ex.Message, this);
        }
        protected void OnLogged(string msg)
        {
            Logger.Instance.Log("{0} for {1}", msg, this);
        }
        #endregion

        /// <summary>
        /// To log all the fetched values into trace logging stream or not
        /// </summary>
        public static bool LogFetchedValues { get; set; }

        /// <summary>
        /// To log debug messages into trace logging stream or not
        /// </summary>
        public static bool LogDebugMessage { get; set; }

        protected int bufferSize;

        [DataMember(Name="CounterInstance")]
        public CounterInstance Instance { get; protected set; }
        [DataMember]
        public int Interval { get; protected set; }
        public bool HasCreated { get; protected set; }
        public bool IsCreating { get; protected set; }
        public bool HasFaulted { get; protected set; }
        public long? RunIdInCreating { get; protected set; }
        protected int? intervalInCreating;

        [DataMember]
        public TaskStatus Status
        {
            get { return this.Instance.IsRunning ? TaskStatus.Running : 
                            this.HasFaulted ? (this.HasCreated ? TaskStatus.Faulted : TaskStatus.Invalid):
                                    this.HasCreated ? TaskStatus.Standby : TaskStatus.NotCreated; }
            // For serialization only
            private set { }
        }

        protected Timer timer;

        public override string ToString()
        {
            return string.Format("{0}, Interval: {1}, Status: {2}", this.Instance, this.Interval, this.Status);
        }

        /// <summary>
        /// Uses ThreadPool to initialize PerformanceCounter
        /// </summary>
        /// <param name="runId">if specified, run after initializing</param>
        /// <param name="interval">interval for running</param>
        internal abstract void CreateCounter(long? runId = null, int? interval = null);

        /// <summary>
        /// Start and set interval
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="interval"></param>
        internal abstract void Start(long runId, int interval);

        internal abstract void Pause(int interval, bool dueToCallerDead = false);

        protected bool toKill = false;
        internal abstract void KillCounter(bool dueToCallerDead = false);

        internal abstract void FaultCounter();

        internal virtual void ChangeInterval(int interval)
        {
            if (this.Interval != interval)
            {
                this.Interval = interval;
                if (this.HasCreated && this.timer != null)
                {
                    this.timer.Change(0, this.Interval * 1000);
                }
            }
        }

        internal void HeartBeat()
        {
            this.Instance.LastHeartBeat = DateTime.Now;
        }
    }
}
