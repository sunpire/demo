﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data.Common;
using System.Data;

namespace PMS.Core
{
    public class DbLogger
    {
        #region Singleton
        private static volatile DbLogger instance;
        private static object syncRoot = new Object();
        public static DbLogger Instance
        {
            get
            {
                /// Double-Check Locking 
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                        {
                            instance = new DbLogger();
                        }
                    }
                }
                return instance;
            }
        }
        protected DbLogger()
        {
            this.buffer = new ConcurrentQueue<Tuple<string, bool, long, Data>>();
            this.isSavingToDb = false;
            this.timer = new Timer(new TimerCallback(TimerRun), null, 1000, 1000);
        }
        #endregion

        /// <summary>
        /// The tuple is composited by CounterUniqueName, IsInteger, RunId, Data in turn
        /// </summary>
        private ConcurrentQueue<Tuple<string, bool, long, Data>> buffer;
        private Timer timer;
        private bool isSavingToDb;

        private string connStr;
        public string ConnectionString 
        {
            get { return this.connStr; } 
            set 
            {
                this.connStr = value;
                this.ReleaseDbConnection();
                this.db = new Db(value);
            } 
        }

        private Db db;

        /// <summary>
        /// This method is thread-safe
        /// </summary>
        /// <param name="ci"></param>
        /// <param name="data"></param>
        public void EnqueueToLogToDb(CounterInstance ci, Data data)
        {
            // ci.RunId will be cleaned when the related task has been stopped
            if (ci.RunId.HasValue)
            {
                // so we store all the data we need (SafeCounterKey, IsInteger, RunId) in order not to run into NullReference exception
                this.buffer.Enqueue(new Tuple<string, bool, long, Data>(ci.TheCounter.SafeCounterKey, ci.TheCounter.IsInteger, ci.RunId.Value, data));
            }
        }

        /// <summary>
        /// This method is thread-safe
        /// </summary>
        /// <param name="counterKey"></param>
        /// <param name="isInteger"></param>
        /// <param name="runId"></param>
        /// <param name="data"></param>
        public void EnqueueToLogToDb(string counterKey, bool isInteger, long runId, Data data)
        {
            this.buffer.Enqueue(new Tuple<string, bool, long, Data>(counterKey, isInteger, runId, data));
        }

        private void TimerRun(object state)
        {
            lock (syncRoot)
            {
                if (this.isSavingToDb)
                {
                    return;
                }
                if (this.buffer.Count == 0)
                {
                    // Don't need to check Db Connection too frequently
                    //this.ReleaseDbConnection();
                    return;
                }
                isSavingToDb = true;
                int currentCount = this.buffer.Count;
                // just to save currentCount entries into Db, the rest entries will be saved in next TimerCallback
                Tuple<string, bool, long, Data> tuple;
                for (int i = 0; i < currentCount; i++)
                {
                    if (this.buffer.Count > 0)
                    {
                        if (this.buffer.TryDequeue(out tuple))
                        {
                            this.LogToDb(tuple);
                        }
                        else
                        {
                            Logger.Instance.Log("Failed to dequeue from buffer at {0}", "TryDequeue() in TimerRun");
                        }
                    }
                }
                isSavingToDb = false;
            }
        }

        public void Kill()
        {
            this.ReleaseDbConnection();
        }

        #region Db Access
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tuple">The tuple is composited by CounterUniqueName, IsInteger, RunId, Data</param>
        private void LogToDb(Tuple<string, bool, long, Data> tuple)
        {
            if (this.db != null)
            {
                if (tuple == null)
                {
                    Logger.Instance.Log("Data to log is null at {0}", "LogToDb(Tuple<string, bool, long, Data>)");
                    return;
                }

                try
                {
                    using (DbCommand cmd = this.db.CreateCommand(tuple.Item2 ? "dbo.PostDataLong" : "dbo.PostDataFloat"))
                    {
                        this.db.AppendParameter(cmd, "@RunId", tuple.Item3, DbType.Int64);
                        this.db.AppendParameter(cmd, "@DataLabel", tuple.Item1, DbType.String);
                        this.db.AppendParameter(cmd, "@DataCreationTime", tuple.Item4.LoggedTime, DbType.DateTime);
                        if (tuple.Item2)
                        {
                            this.db.AppendParameter(cmd, "@Data", System.Convert.ToInt64(tuple.Item4.Value), DbType.Int64);
                        }
                        else
                        {
                            this.db.AppendParameter(cmd, "@Data", tuple.Item4.Value, DbType.Double);
                        }
                        this.db.ExecuteProcedureWithConnection(cmd);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Instance.Log(ex, "{0} occurred at {1}", ex.Message, "LogToDb(Tuple<string, bool, long, Data>)");
                }
            }
        }

        private void ReleaseDbConnection()
        {
            if (this.db != null)
            {
                this.db.CloseActiveConnection();
            }
        }
        #endregion
    }
}
