﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMS.Core
{
    internal abstract class BaseEventLogBehavior
    {
        public bool IsPerforming { get; protected set; }
        
        public void Reset()
        {
            this.IsPerforming = false;
        }
        
        public abstract int Perform(string machine, EventLogCounter counter, List<AdvancedTaskRequest> requests);

        /// <summary>
        /// Uses AdvancedTaskRequest.Start as LoggedTime
        /// </summary>
        /// <param name="isInteger"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        protected virtual int Store(bool isInteger, EventLogResult result)
        {
            if (result == null)
            {
                return 0;
            }
            int count = 0;
            // Sorted by datetime DESC
            for (int i = result.RequestResults.Count - 1; i >= 0; i--)
            {
                EventLogRequestResult requestResult = result.RequestResults[i];
                foreach (string key in requestResult.GroupResults.Keys)
                {
                    DbLogger.Instance.EnqueueToLogToDb(key, isInteger, requestResult.Request.RunId, new Data()
                    {
                        Value = requestResult.GroupResults[key].Value,
                        LoggedTime = requestResult.Request.Start
                    });
                    count++;
                }
            }
            return count;
        }

        protected string CombineToSafeCounterKey(string key, string subKey)
        {
            string finalKey = string.Format(@"{0}\{1}", key, subKey);
            if (finalKey.Length > 50)
            {
                finalKey = string.Format(@"{0}\{1}", key.Substring(0, 49 - subKey.Length), subKey);
            }
            return finalKey;
        }

        protected void Log(string format, params object[] args)
        {
            if (Task.LogDebugMessage)
            {
                Logger.Instance.Log(format, args);
            }
        }

        protected void LogErrorMessage(string format, params object[] args)
        {
            Logger.Instance.Log(string.Concat("[Error]", format), args);
        }

        protected void Log(Exception ex, string format, params object[] args)
        {
            Logger.Instance.Log(ex, format, args);
        }
    }

    internal class EventLogBehaviorFactory
    {
        public static BaseEventLogBehavior CreateEventLogBehavior(EventLogCounter counter)
        {
            if (counter.QueryMethod == EventLogQueryMethodType.Wmi)
            {
                if (counter.GroupType == EventLogEntryAggregationType.Count)
                {
                    return new WmiCountEventLogBehavior();
                }
                else if (counter.GroupType == EventLogEntryAggregationType.Avg)
                {
                    return new WmiAverageEventLogBehavior();
                }
                else if (counter.GroupType == EventLogEntryAggregationType.Max)
                {
                    return new WmiMaxEventLogBehavior();
                }
                else if (counter.GroupType == EventLogEntryAggregationType.Min)
                {
                    return new WmiMinEventLogBehavior();
                }
            }
            else
            {
                throw new NotImplementedException("Query EventLog directly not implemented");
            }
            return null;
        }
    }
}
