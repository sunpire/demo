﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using Sunpire.Framework;

namespace Sunpire.DA
{
    /// This file provides all the Db operations without any Db transactions, 
    /// such a Db operation closes Db connection when it is done。
    /// 
    /// <summary>
    /// Db Access Layer based on ADO.NET Abstract Factory Pattern.
    /// 
    /// The best practice about using Explicit Db Transaction or Implicit Db Transaction is to use/pass a Db connection
    /// instance from starting to the end.
    /// 
    /// Supplement: SQL Server 2008 enhances Local Db Transaction, it just requires the same Db connection string when
    ///             using Local Db Transaction no matter how many Db connection instances are created and no matter how
    ///             many times Open()/Close() are called.
    /// </summary>
    public partial class Db
    {
        #region ConnectionString
        /// <summary>
        /// static common ConnectionString
        /// </summary>
#if DEBUG
        private static string commonConnString = @"Data Source=.;Persist Security=True;";
#else
        private static string commonConnString = null;
#endif
        /// <summary>
        /// static common ConnectionString
        /// </summary>
        public static string CommonConnectionString
        {
            get { return Db.commonConnString; }
            set {
                if (!value.IsNullOrEmpty())
                {
                    Db.commonConnString = value;
                }
                else
                {
                    throw new System.ArgumentException("Common Connection String can not be empty.");
                }
            }
        }

        private string connString;
        /// <summary>
        /// ConnectionString in current instance
        /// </summary>
        public string ConnectionString
        {
            get { return this.connString; }
            set { this.connString = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public System.Data.Common.DbConnection CreateConnection()
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            conn.ConnectionString = this.connString;
            return conn;
        }
        #endregion

        #region GetFactoryByConfig()
        /// <summary>
        ///
        /// </summary>
        public Db()
            : this(Db.CommonConnectionString, Framework.Config.DbProvider)
        {
        }
        /// <summary>
        ///
        /// </summary>
        /// <param name="connectionString"></param>
        public Db(string connectionString)
            :this(connectionString, Framework.Config.DbProvider)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="dbProvider"></param>
        public Db(string connectionString, string dbProvider)
        {
            if (!connectionString.IsNullOrEmpty())
            {
                this.connString = connectionString;
            }
            else
            {
                throw new System.ArgumentException("Given connection string can not be empty.");
            }
            DbProviderFactory fact = this.GetFactoryByConfig(dbProvider);
            if (fact != null)
            {
                this.factory = fact;
            }
            else
            {
                throw new System.ArgumentException("Given dbProvider is not support.");
            }
        }

        /// <summary>
        /// .NET 2.0 DbProviderFactory
        /// </summary>
        private DbProviderFactory factory = null;
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private DbProviderFactory GetFactoryByConfig(string config)
        {
            if (config.ToLower() == "MSSql".ToLower())
            {
                //System.Data.SqlClient.SqlClientFactory.Instance
                return DbProviderFactories.GetFactory("System.Data.SqlClient");
            }
            else if (config.ToLower() == "SQLite".ToLower())
            {
                /// If there is no sector below in App.config
                /// <configuration>
                /// <system.data>
                ///     <DbProviderFactories>
                ///       <remove invariant="System.Data.SQLite"/>
                ///       <add name="SQLite Data Provider" invariant="System.Data.SQLite" description=".Net Framework Data Provider for SQLite" type="System.Data.SQLite.SQLiteFactory, System.Data.SQLite" />
                ///     </DbProviderFactories>
                ///  </system.data>
                ///</configuration>
                /// calling DbProviderFactories.GetFactory("System.Data.SQLite") leads to error below for .NET 2.0:
                ///     System.ArgumentException: Couldn't find the requested .Net Framework DbProvider, maybe it is not installed.
                ///         On System.Data.Common.DbProviderFactories.GetFactory(String providerInvariantName)
                /// or it throws exception as below for .NET 3.5:
                ///     System.Configuration.ConfigurationErrorsException: The regesited .Net Framework DbProvider couldn't be found or loaded.
                ///         On System.Data.Common.DbProviderFactories.GetFactory(DataRow providerRow)
                ///         On System.Data.Common.DbProviderFactories.GetFactory(String providerInvariantName)
                return DbProviderFactories.GetFactory("System.Data.SQLite");
                /// So, for easy use, we can instantiate SQLiteFactory directly.
                //return new System.Data.SQLite.SQLiteFactory();
            }
            else if (config.ToLower() == "OleDb".ToLower())
            {
                return System.Data.OleDb.OleDbFactory.Instance;
                //return DbProviderFactories.GetFactory("System.Data.OleDbClient");
            }
            else if (config.ToLower() == "Oracle".ToLower())
            {
                return DbProviderFactories.GetFactory("System.Data.OracleClient");
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region SQLite 
        //public static KeyValuePair<string, Db> SQLiteDb
        //{
        //}
        //private static KeyValuePair<string, Db> dbOfSQLite;

        #endregion


        #region Command and Parameters
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbCommand CreateCommand(string commandText)
        {
            DbCommand cmd = this.factory.CreateCommand();
            if (!commandText.IsNullOrEmpty())
            {
                cmd.CommandText = commandText;
            } 
            return cmd;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <returns></returns>
        public object GetParameterValue(System.Data.Common.DbCommand command, string parameterName)
        {
            try
            {
                return command.Parameters[parameterName].Value;
            }
            catch (IndexOutOfRangeException ex) 
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), ex);
                throw; 
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        private string GetCommandDetail(System.Data.Common.DbCommand c)
        {
            System.Text.StringBuilder b = new System.Text.StringBuilder(System.Environment.NewLine + "CommandText:");
            b.AppendLine(c.CommandText);
            b.AppendLine("Parameters:");
            foreach (System.Data.Common.DbParameter p in c.Parameters)
            {
                b.Append(p.ParameterName);
                b.Append(" ");
                b.Append(p.DbType.ToString());
                b.Append(" = ");
                if (p.Value != null && !p.Value.Equals(System.DBNull.Value))
                {
                    b.AppendLine(p.Value.ToString());
                }
                else
                {
                    b.AppendLine("null");
                }
            }
            return b.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public System.Data.Common.DbParameter CreateParameter()
        {
            return this.factory.CreateParameter();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, object value)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.Value = value;
            command.Parameters.Add(p);
            return p;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="value"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, object value, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Value = value;
            command.Parameters.Add(p);
            return p;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, System.Data.Common.DbParameter parameter)
        {
            command.Parameters.Add(parameter);
            return parameter;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <param name="srcColumn"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size, string srcColumn)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.SourceColumn = srcColumn;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <param name="srcColumn"></param>
        /// <param name="version"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size, string srcColumn, System.Data.DataRowVersion version)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            p.SourceColumn = srcColumn;
            p.SourceVersion = version;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <param name="srcColumn"></param>
        /// <param name="version"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, string srcColumn, System.Data.DataRowVersion version)
        {
            DbParameter p = command.CreateParameter();
            p.ParameterName = parameterName;
            p.DbType = type;
            p.SourceColumn = srcColumn;
            p.SourceVersion = version;
            p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type, int size)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            p.DbType = type;
            p.Size = size;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName, System.Data.DbType type)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            p.DbType = type;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendOutputParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.Output;
            p.ParameterName = parameterName;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName"></param>
        /// <returns></returns>
        public System.Data.Common.DbParameter AppendReturnParameter(System.Data.Common.DbCommand command, string parameterName)
        {
            DbParameter p = command.CreateParameter();
            p.Direction = System.Data.ParameterDirection.ReturnValue;
            p.ParameterName = parameterName;
            //p.Value = DBNull.Value;
            command.Parameters.Add(p);
            return p;
        }


        #endregion

        #region Supporting
        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameter"></param>
        /// <param name="stringValue"></param>
        public static void SetValueToDbInt(System.Data.Common.DbParameter parameter, string stringValue)
        {
            if (stringValue.IsNullOrEmpty())
            {
                parameter.Value = System.DBNull.Value;
            }
            else
            {
                int result;
                if (int.TryParse(stringValue, out result))
                {
                    parameter.Value = result;
                }
                else
                {
                    parameter.Value = System.DBNull.Value;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameter"></param>
        /// <param name="stringValue"></param>
        public static void SetValueToDbDecimal(System.Data.Common.DbParameter parameter, string stringValue)
        {
            if (stringValue.IsNullOrEmpty())
            {
                parameter.Value = System.DBNull.Value;
            }
            else
            {
                decimal result;
                if (decimal.TryParse(stringValue, out result))
                {
                    parameter.Value = result;
                }
                else
                {
                    parameter.Value = System.DBNull.Value;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="theValue"></param>
        /// <returns></returns>
        public static object ToDbValue(string theValue)
        {
            if (theValue.IsNullOrEmpty()) 
            { 
                return System.DBNull.Value;
            } 
            else 
            { 
                return theValue; 
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="theValue"></param>
        /// <returns></returns>
        public static object ToDbValue(object theValue)
        {
            return theValue == null ? System.DBNull.Value : (theValue.ToString().IsNullOrEmpty() ? System.DBNull.Value : theValue);
        }
        #endregion

        #region Db Operations without Transaction
        #region Query and DataTable
        #region ExecuteScalar
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public object ExecuteScalar(string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            object rst = null;
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 0;
                conn.Open();

                rst = selectCommand.ExecuteScalar();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
            }
            finally
            {
                conn.Close();
            }
            return rst;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public object ExecuteScalar(string connectionString, string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.ExecuteScalar(connectionString, selectCommand);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public object ExecuteScalar(System.Data.Common.DbCommand selectCommand)
        {
            return this.ExecuteScalar(this.connString, selectCommand);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public object ExecuteScalar(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.ExecuteScalar(this.connString, selectCommand);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public bool DoesDataExist(string connectionString, string selectCommandText)
        {
            return this.ExecuteScalar(connectionString, selectCommandText) != null;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public bool DoesDataExist(string selectCommandText)
        {
            return this.DoesDataExist(this.connString, selectCommandText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public bool DoesDataExist(System.Data.Common.DbCommand selectCommand)
        {
            return this.ExecuteScalar(this.connString, selectCommand) != null;
        }
        #endregion

        #region Schema
        /// <summary>
        /// Returns schema information for the data source of this System.Data.Common.DbConnection
        /// </summary>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema()
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema();
            }
        }

        /// <summary>
        /// Returns schema information for the data source of this System.Data.Common.DbConnection
        /// using the specified string for the schema name.
        /// </summary>
        /// <param name="collectionName">Specifies the name of the schema to return</param>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema(string collectionName)
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema(collectionName);
            }
        }
        /// <summary>
        ///              Returns schema information for the data source of this System.Data.Common.DbConnection
        ///              using the specified string for the schema name and the specified string array
        ///              for the restriction values.
        /// </summary>
        /// <param name="collectionName">Specifies the name of the schema to return</param>
        /// <param name="restrictionValues">Specifies a set of restriction values for the requested schema</param>
        /// <returns>A System.Data.DataTable that contains schema information</returns>
        public System.Data.DataTable GetSchema(string collectionName, string[] restrictionValues)
        {
            using (System.Data.Common.DbConnection conn = this.CreateConnection())
            {
                conn.Open();
                return conn.GetSchema(collectionName, restrictionValues);
            }
        }
        #endregion

        #region GetDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.DataTable GetDataTable(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetDataTable(this.connString, selectCommand);
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.DataTable GetDataTable(System.Data.Common.DbCommand selectCommand)
        {
            return this.GetDataTable(this.connString, selectCommand);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.DataTable GetDataTable(string connectionString, string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetDataTable(connectionString, selectCommand);
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.DataTable GetDataTable(string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 120;
                conn.Open();
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                //table = reader.GetSchemaTable();
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
            }
            finally
            {
                conn.Close();
            }
            return table == null ? new System.Data.DataTable() : table ;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> GetValueText(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetValueText(this.connString, selectCommand);
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> GetValueText(System.Data.Common.DbCommand selectCommand)
        {
            return this.GetValueText(this.connString, selectCommand);

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> GetValueText(string connectionString, string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateCommand(selectCommandText))
            {
                return this.GetValueText(connectionString, selectCommand);
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> GetValueText(string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Collections.Generic.List<Framework.ValueText> list = new System.Collections.Generic.List<Framework.ValueText>();
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 0;
                conn.Open();
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    list.Add(new Framework.ValueText(reader.GetValue(0).ToString(), reader.GetValue(1).ToString()));
                }
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
            }
            finally
            {
                conn.Close();
            }
            return list;
        }

        #endregion

        #region AppendToDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        public void AppendToDataTable(System.Data.DataTable table, string connectionString, System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 0;
                conn.Open();
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
            }
            finally
            {
                conn.Close();
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        public void AppendToDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand)
        {
            this.AppendToDataTable(table, this.connString, selectCommand);
        }
        #endregion

        #region SynchronizeDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="connectionString"></param>
        /// <param name="selectCommand"></param>
        /// <param name="primaryKeyName"></param>
        /// <param name="importedCount"></param>
        /// <param name="refreshedCount"></param>
        public void SynchronizeDataTable(System.Data.DataTable table, string connectionString, System.Data.Common.DbCommand selectCommand, string[] primaryKeyName, ref int importedCount, ref int refreshedCount)
        {
            // retrieve configuration from database
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                selectCommand.Connection = conn;
                selectCommand.CommandTimeout = 0;
                conn.Open();
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    bool canAdd = true;
                    System.Data.DataRow foundRow = null;
                    if (primaryKeyName != null)
                    {
                        object[] keys = new object[primaryKeyName.Length];
                        for (int i = 0; i < primaryKeyName.Length; i++)
                        {
                            keys[i] = reader.GetValue(i);
                        }

                        foundRow = table.Rows.Find(keys);
                        if (foundRow != null)
                        {
                            canAdd = false;
                        }
                    }
                    if (canAdd)
                    {
                        System.Data.DataRow row = table.NewRow();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }
                        table.Rows.Add(row);
                        importedCount++;
                    }
                    else
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            foundRow[i] = reader.GetValue(i);
                        }
                        refreshedCount++;
                    }
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
            }
            finally
            {
                conn.Close();
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        /// <param name="primaryKeyName"></param>
        /// <param name="importedCount"></param>
        /// <param name="refreshedCount"></param>
        public void SynchronizeDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand, string[] primaryKeyName, ref int importedCount, ref int refreshedCount)
        {
            this.SynchronizeDataTable(table, this.connString, selectCommand, primaryKeyName, ref importedCount, ref refreshedCount);
        }
        #endregion
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// DbCommand.ExecuteNonQuery()
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string connectionString,System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandTimeout = 0;
                conn.Open();
                return command.ExecuteNonQuery();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
            }
            finally
            {
                conn.Close();
            }
            return -1;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(System.Data.Common.DbCommand command)
        {
            return this.ExecuteNonQuery(this.connString, command);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string commandText)
        {
            using (DbCommand command = this.CreateCommand(commandText))
            {
                return this.ExecuteNonQuery(this.connString, command);
            }
        }
        #endregion

        #region ExecuteProcedure
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteProcedure(string connectionString,System.Data.Common.DbCommand command)
        {
            int result = -1;
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.Common.DbParameter parameter = null;
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                parameter = this.AppendReturnParameter(command, "@Return");
                conn.Open();
                command.ExecuteNonQuery();
                
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
            }
            finally
            {
                result = (int)parameter.Value;
                conn.Close();
            }
            return result;

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ExecuteProcedure(System.Data.Common.DbCommand command)
        {
            return this.ExecuteProcedure(this.connString, command);
        }
        #endregion

        #region ExecuteProcedureForDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Data.DataTable ExecuteProcedureForDataTable(string connectionString, System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                conn.Open();

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                //table = reader.GetSchemaTable();

                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e);
            }
            finally
            {
                conn.Close();
            }
            return table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Data.DataTable ExecuteProcedureForDataTable(System.Data.Common.DbCommand command)
        {
            return this.ExecuteProcedureForDataTable(this.connString, command);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Collections.Generic.Dictionary<string, string> ExecuteProcedureForDictionary(string connectionString, System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            System.Collections.Generic.Dictionary<string, string> dict = new System.Collections.Generic.Dictionary<string, string>();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                conn.Open();

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read() && reader.FieldCount >= 2)
                {
                    dict.Add(reader.GetString(0), reader.GetString(1));
                }
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e);
            }
            finally
            {
                conn.Close();
            }
            return dict;

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Collections.Generic.Dictionary<string, string> ExecuteProcedureForDictionary(System.Data.Common.DbCommand command)
        {
            return this.ExecuteProcedureForDictionary(this.connString, command);
        }       
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        public void ExecuteProcedureToRefreshDataTable( System.Data.DataTable table, string connectionString, System.Data.Common.DbCommand command)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                conn.Open();

                table.Rows.Clear();

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (NullReferenceException nulle)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), nulle);
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
            }
            catch (Exception e)
            {
                Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e);
            }
            finally
            {
                conn.Close();
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="command"></param>
        public void ExecuteProcedureToRefreshDataTable(System.Data.DataTable table,  System.Data.Common.DbCommand command)
        {
            this.ExecuteProcedureToRefreshDataTable(table,this.connString,command);
        }
        #endregion

        #region DbDataAdapter
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter CreateDataAdapter(string connectionString, string selectCommandText)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            adapter.SelectCommand.Connection = conn;
            adapter.SelectCommand = conn.CreateCommand();
            adapter.SelectCommand.CommandText = selectCommandText;
            return adapter;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter CreateDataAdapter(string selectCommandText)
        {
            return this.CreateDataAdapter(this.connString, selectCommandText);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter CreateDataAdapter(System.Data.Common.DbCommand selectCommand)
        {
            if (selectCommand.Connection == null)
            {
                selectCommand.Connection = this.factory.CreateConnection();
                selectCommand.Connection.ConnectionString = this.connString;
            }
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = selectCommand;
            return adapter;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter CreateDataAdapter()
        {
            return this.factory.CreateDataAdapter();
        }

        #region DbDataAdapter.Fill()
        /// <summary>
        /// DbDataAdapter.Fill(DataTable)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            int result = -1;
            try
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection == null)
                {
                    adapter.SelectCommand.Connection = this.factory.CreateConnection();
                    adapter.SelectCommand.Connection.ConnectionString = connectionString;
                }
                adapter.SelectCommand.Connection.Open();
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(dt);
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                }
                else
                {
                    Framework.ExceptionHandler.Handle(dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Framework.ExceptionHandler.Handle(nulle);
            }
            catch (SystemException syse)
            {
                Framework.ExceptionHandler.Handle(syse);
            }
            finally
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection != null && 
                    adapter.SelectCommand.Connection.State == System.Data.ConnectionState.Open)
                {
                    adapter.SelectCommand.Connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// DbDataAdapter.Fill(DataTable)
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            return this.DbDataAdapterFill(this.connString, adapter, dt);
        }

        /// <summary>
        /// DbDataAdapter.Fill(DataSet)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int DbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            int result = -1;
            try
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection == null)
                {
                    adapter.SelectCommand.Connection = this.factory.CreateConnection();
                    adapter.SelectCommand.Connection.ConnectionString = connectionString;
                }
                adapter.SelectCommand.CommandTimeout = 0;
                adapter.SelectCommand.Connection.Open();
                result = adapter.Fill(ds);
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                }
                else
                {
                    Framework.ExceptionHandler.Handle(dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Framework.ExceptionHandler.Handle(nulle);
            }
            catch (SystemException syse)
            {
                Framework.ExceptionHandler.Handle(syse);
            }
            finally
            {
                if (adapter.SelectCommand != null && adapter.SelectCommand.Connection != null &&
                    adapter.SelectCommand.Connection.State == System.Data.ConnectionState.Open)
                {
                    adapter.SelectCommand.Connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// DbDataAdapter.Fill(DataSet)
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int DbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            return this.DbDataAdapterFill(this.connString, adapter, ds);
        }
        #endregion

        #region DbDataAdapter.Update()
        /// <summary>
        /// DbDataAdapter.Update(DataTable)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            int result = -1;
            try
            {
                conn.ConnectionString = connectionString;
                if (adapter.SelectCommand != null)
                {
                    adapter.SelectCommand.Connection = conn;
                    adapter.SelectCommand.CommandTimeout = 0;
                }
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = conn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = conn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = conn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                conn.Open();
                result = adapter.Update(dt);
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                }
                if (adapter.UpdateCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.UpdateCommand), dbe);
                }
                if (adapter.InsertCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.InsertCommand), dbe);
                }
                if (adapter.DeleteCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.DeleteCommand), dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Framework.ExceptionHandler.Handle(nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                Framework.ExceptionHandler.Handle(dbe);
            }
            catch (SystemException syse)
            {
                Framework.ExceptionHandler.Handle(syse);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// DbDataAdapter.Update(DataTable)
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            return this.DbDataAdapterUpdate(this.connString, adapter, dt);
        }

        /// <summary>
        /// DbDataAdapter.Update(DataSet)
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            int result = -1;
            System.Data.Common.DbConnection conn = this.factory.CreateConnection();
            try
            {
                conn.ConnectionString = connectionString;
                if (adapter.SelectCommand != null)
                {
                    adapter.SelectCommand.Connection = conn;
                    adapter.SelectCommand.CommandTimeout = 0;
                }
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = conn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = conn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = conn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                conn.Open();
                result = adapter.Update(ds);
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                if (adapter.SelectCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                }
                if (adapter.UpdateCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.UpdateCommand), dbe);
                }
                if (adapter.InsertCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.InsertCommand), dbe);
                }
                if (adapter.DeleteCommand != null)
                {
                    Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.DeleteCommand), dbe);
                }
            }
            catch (ArgumentNullException nulle)
            {
                Framework.ExceptionHandler.Handle(nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                Framework.ExceptionHandler.Handle(dbe);
            }
            catch (SystemException syse)
            {
                Framework.ExceptionHandler.Handle(syse);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// DbDataAdapter.Update(DataSet)
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int DbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            return this.DbDataAdapterUpdate(this.connString, adapter, ds);
        }
        #endregion

        /// <summary>
        /// DbCommandBuilder
        /// </summary>
        /// <returns></returns>
        public System.Data.Common.DbCommandBuilder CreateCommandBuilder()
        {
            return this.factory.CreateCommandBuilder();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbDataAdapter"></param>
        /// <returns></returns>
        public System.Data.Common.DbCommandBuilder CreateCommandBuilder(System.Data.Common.DbDataAdapter dbDataAdapter)
        {
            if (dbDataAdapter is System.Data.SqlClient.SqlDataAdapter)
            {
                return new System.Data.SqlClient.SqlCommandBuilder(dbDataAdapter as System.Data.SqlClient.SqlDataAdapter);
            }
            //else if (dbDataAdapter is System.Data.SQLite.SQLiteDataAdapter)
            //{
            //    return new System.Data.SQLite.SQLiteCommandBuilder(dbDataAdapter as System.Data.SQLite.SQLiteDataAdapter);
            //}
            else if (dbDataAdapter is System.Data.OleDb.OleDbDataAdapter)
            {
                return new System.Data.OleDb.OleDbCommandBuilder(dbDataAdapter as System.Data.OleDb.OleDbDataAdapter);
            }
            else
            {
                return this.factory.CreateCommandBuilder();
            }
        }
        #endregion
        #endregion
    }
}
