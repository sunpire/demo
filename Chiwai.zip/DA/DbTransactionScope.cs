﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using Sunpire.Framework;

namespace Sunpire.DA
{
    /// Implicit Db Transaction(TransactionScope).
    /// First, create a ScopeationScope object and pass it to all Db Commands to be used, at last, implicitly commit transaction and close Db connection.
    /// General use:
    /// Instantiate Db,
    /// Call try{  using( TransactionScope ts = new TransactionScope() ),
    /// Then ScopeBegin(),
    /// Then do Db operations(method name starts with 'Scope'), a ScopeException will be thrown as well if any exception occurs during doing these operations
    /// Then catch{ ScopeException }
    /// Finally finally{ ScopeEnd() }
    public partial class Db
    {
        #region ScopeException
        /// <summary>
        /// 
        /// </summary>
        public class ScopeException : System.Exception
        {
            private string cmdDetail;
            public string CommandDetail
            {
                get { return this.cmdDetail; }
            }
            private Exception srcException;
            public Exception SourceException
            {
                get { return this.srcException; }
            }
            public ScopeException(string cmdDetail , Exception srcException)
            {
                this.srcException = srcException;
                this.cmdDetail = cmdDetail;
                
            }
        }
        #endregion

        #region ÓÃÓÚ Command
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbCommand CreateScopeCommand(string commandText)
        {
            if (!this.IsConnectionOpen)
            {
                return this.CreateCommand(commandText);
            }
            DbCommand cmd = this.transConn.CreateCommand();
            if (!commandText.IsNullOrEmpty())
            {
                cmd.CommandText = commandText;
            }
            return cmd;
        }
        #endregion
        #region Scope Action
        #region BeginScopeaction Commit  Rollback
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool ScopeBegin()
        {
            try
            {
                if (this.transConn == null)
                {
                    this.transConn = this.factory.CreateConnection();
                    this.transConn.ConnectionString = this.connString;
                }
                if (! this.IsConnectionOpen)
                {
                    this.transConn.Open();
                }
                return true;
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                Framework.ExceptionHandler.Handle(dbe);
            }
            catch (System.Transactions.TransactionException te)
            {
                Framework.ExceptionHandler.Handle(te);
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool ScopeEnd()
        {
            try
            {
                this.transConn.Close();
                return true;
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(e1);
            }
            catch (Exception ex)
            {
                Framework.ExceptionHandler.Handle(ex);
            }
            return false;
        }
        #endregion

        #region DataTable
        #region ExecuteScalar
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public object ScopeExecuteScalar(System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return null;
            }

            object rst = null;
            try
            {
                selectCommand.CommandTimeout = 0;
                rst = selectCommand.ExecuteScalar();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
                throw new ScopeException(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
                throw new ScopeException(selectCommand.CommandText, e2);
            }
            return rst;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public object ScopeExecuteScalar(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateScopeCommand(selectCommandText))
            {
                return this.ScopeExecuteScalar(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public bool ScopeDoesDataExist(string selectCommandText)
        {
            return this.ScopeExecuteScalar(selectCommandText) != null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public bool ScopeDoesDataExist(System.Data.Common.DbCommand selectCommand)
        {
            return this.ScopeExecuteScalar(selectCommand) != null;
        }
        #endregion

        #region GetDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.DataTable ScopeGetDataTable(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateScopeCommand(selectCommandText))
            {
                return this.ScopeGetDataTable(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.DataTable ScopeGetDataTable(System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Data.DataTable();
            }

            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
                throw new ScopeException(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
                throw new ScopeException(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
                throw new ScopeException(selectCommand.CommandText, e);
            }
            return table == null ? new System.Data.DataTable() : table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> ScopeGetValueText(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateScopeCommand(selectCommandText))
            {
                return this.ScopeGetValueText(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> ScopeGetValueText(System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Collections.Generic.List<Framework.ValueText>();
            }

            System.Collections.Generic.List<Framework.ValueText> list = new System.Collections.Generic.List<Framework.ValueText>();
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    list.Add(new Framework.ValueText(reader.GetValue(0).ToString(), reader.GetValue(1).ToString()));
                }
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
                throw new ScopeException(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
                throw new ScopeException(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
                throw new ScopeException(selectCommand.CommandText, e);
            }
            return list;
        }

        #endregion

        #region AppendToDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        public void ScopeAppendToDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return ;
            }

            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
                throw new ScopeException(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
                throw new ScopeException(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
                throw new ScopeException(selectCommand.CommandText, e );
            }
        }
        #endregion
        #region SynchronizeDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        /// <param name="primaryKeyName"></param>
        /// <param name="importedCount"></param>
        /// <param name="refreshedCount"></param>
        public void ScopeSynchronizeDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand, string[] primaryKeyName, ref int importedCount, ref int refreshedCount)
        {
            if (!this.IsConnectionOpen)
            {
                return ;
            }

            // retrieve configuration from database
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    bool canAdd = true;
                    System.Data.DataRow foundRow = null;
                    if (primaryKeyName != null)
                    {
                        object[] keys = new object[primaryKeyName.Length];
                        for (int i = 0; i < primaryKeyName.Length; i++)
                        {
                            keys[i] = reader.GetValue(i);
                        }

                        foundRow = table.Rows.Find(keys);
                        if (foundRow != null)
                        {
                            canAdd = false;
                        }
                    }
                    if (canAdd)
                    {
                        System.Data.DataRow row = table.NewRow();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }
                        table.Rows.Add(row);
                        importedCount++;
                    }
                    else
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            foundRow[i] = reader.GetValue(i);
                        }
                        refreshedCount++;
                    }
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e1);
                throw new ScopeException(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e2);
                throw new ScopeException(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                //Framework.ExceptionHandler.Handle(selectCommand.CommandText, e);
                throw new ScopeException(selectCommand.CommandText, e );
            }
        }
        #endregion
        #endregion


        #region ExecuteNonQuery
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ScopeExecuteNonQuery(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return -1;
            }

            try
            {
                command.CommandTimeout = 0;
                return command.ExecuteNonQuery();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
                throw new ScopeException(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
                throw new ScopeException(this.GetCommandDetail(command), e2);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public int ScopeExecuteNonQuery(string commandText)
        {
            using (DbCommand command = this.CreateScopeCommand(commandText))
            {
                return this.ScopeExecuteNonQuery(command);
            }
        }
        #endregion

        #region ExecuteProcedure
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int ScopeExecuteProcedure(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }
            
            int result = -1;
            System.Data.Common.DbParameter parameter = null;
            try
            {
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                parameter = this.AppendReturnParameter(command, "@Return");
                command.ExecuteNonQuery();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
                throw new ScopeException(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
                throw new ScopeException(this.GetCommandDetail(command), e2);
            }
            finally
            {
                result = (int)parameter.Value;
            }
            return result;
        }
        #endregion

        #region ExecuteProcedure
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Data.DataTable ScopeExecuteProcedureForDataTable(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Data.DataTable();
            }

            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }


                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e1);
                throw new ScopeException(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e2);
                throw new ScopeException(this.GetCommandDetail(command), e2);
            }
            catch (Exception e)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(command), e);
                throw new ScopeException(this.GetCommandDetail(command), e);
            }
            return table;
        }
        #endregion

        #region DbDataAdapter
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter ScopeCreateDataAdapter(string selectCommandText)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = this.CreateScopeCommand(selectCommandText);
            return adapter;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter ScopeCreateDataAdapter(System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = selectCommand;
            return adapter;
        }

        #region DbDataAdapter.Fill()
        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int ScopeDbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(dt);
            }

            catch (InvalidOperationException ioe)
            {
                //Framework.ExceptionHandler.Handle(ioe);
                throw new ScopeException(string.Empty, ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                throw new ScopeException(this.GetCommandDetail(adapter.SelectCommand), dbe);
            }
            catch (NullReferenceException nre)
            {
                //Framework.ExceptionHandler.Handle(nre);
                throw new ScopeException(string.Empty,nre);
            }
            catch (ArgumentNullException nulle)
            {
                //Framework.ExceptionHandler.Handle(nulle);
                throw new ScopeException(string.Empty,nulle);
            }
            catch (SystemException syse)
            {
                //Framework.ExceptionHandler.Handle(syse);
                throw new ScopeException(string.Empty,syse);
            }
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int ScopeDbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(ds);
            }
            catch (InvalidOperationException ioe)
            {
                //Framework.ExceptionHandler.Handle(ioe);
                throw new ScopeException(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                throw new ScopeException(this.GetCommandDetail(adapter.SelectCommand), dbe);
            }
            catch (NullReferenceException nre)
            {
                //Framework.ExceptionHandler.Handle(nre);
                throw new ScopeException(string.Empty,nre);
            }
            catch (ArgumentNullException nulle)
            {
                //Framework.ExceptionHandler.Handle(nulle);
                throw new ScopeException(string.Empty,nulle);
            }
            catch (SystemException syse)
            {
                //Framework.ExceptionHandler.Handle(syse);
                throw new ScopeException(string.Empty,syse);
            }
            return result;
        }
        #endregion

        #region DbDataAdapter.Update()
        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int ScopeDbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = this.transConn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = this.transConn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = this.transConn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                result = adapter.Update(dt);
            }
            catch (InvalidOperationException ioe)
            {
                //Framework.ExceptionHandler.Handle(ioe);
                throw new ScopeException(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                string cmdDetail = this.GetCommandDetail(adapter.SelectCommand);
                if (adapter.UpdateCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.UpdateCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "UpdateCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.UpdateCommand);
                }
                if (adapter.InsertCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.InsertCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "InsertCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.InsertCommand);
                }
                if (adapter.DeleteCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.DeleteCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "DeleteCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.DeleteCommand);
                }
                throw new ScopeException(cmdDetail, dbe);
            }
            catch (ArgumentNullException nulle)
            {
                //Framework.ExceptionHandler.Handle(nulle);
                throw new ScopeException(string.Empty,nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                //Framework.ExceptionHandler.Handle(dbe);
                throw new ScopeException(string.Empty,dbe);
            }
            catch (SystemException syse)
            {
                //Framework.ExceptionHandler.Handle(syse);
                throw new ScopeException(string.Empty,syse);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int ScopeDbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = this.transConn;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = this.transConn;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = this.transConn;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                result = adapter.Update(ds);
            }
            catch (InvalidOperationException ioe)
            {
                //Framework.ExceptionHandler.Handle(ioe);
                throw new ScopeException(string.Empty, ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.SelectCommand), dbe);
                string cmdDetail = this.GetCommandDetail(adapter.SelectCommand);
                if (adapter.UpdateCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.UpdateCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "UpdateCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.UpdateCommand);
                }
                if (adapter.InsertCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.InsertCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "InsertCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.InsertCommand);
                }
                if (adapter.DeleteCommand != null)
                {
                    //Framework.ExceptionHandler.Handle(this.GetCommandDetail(adapter.DeleteCommand), dbe);
                    cmdDetail += System.Environment.NewLine + "DeleteCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.DeleteCommand);
                }
                throw new ScopeException(cmdDetail, dbe);
            }
            catch (ArgumentNullException nulle)
            {
                //Framework.ExceptionHandler.Handle(nulle);
                throw new ScopeException(string.Empty, nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                //Framework.ExceptionHandler.Handle(dbe);
                throw new ScopeException(string.Empty, dbe);
            }
            catch (SystemException syse)
            {
                //Framework.ExceptionHandler.Handle(syse);
                throw new ScopeException(string.Empty, syse);
            }
            return result;
        }
        #endregion
        #endregion
        #endregion
    }
}
