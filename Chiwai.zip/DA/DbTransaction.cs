﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using Sunpire.Framework;

namespace Sunpire.DA
{
    /// Explicit Db Transaction.
    /// General use:
    /// Instantiate Db,
    /// Call TransBegin(),
    /// Then do Db operations(method name starts with 'Trans'), TransRollback() will be called automatically if any exception occurs during doing these operations
    /// Finally TransCommit().
    /// 
    /// Also we can set DoesThrowTransException as true to throw TransException:
    /// General use:
    /// Instantiate Db,
    /// Call  try{  TransBegin(), 
    /// Then do Db operations, TransRollback() will be called automatically and a TransException will be thrown as well if any exception occurs during doing these operations
    /// Then TransCommit()  }, 
    /// Finally catch{ TransException }.
    public partial class Db
    {
        #region TransException
        /// <summary>
        /// 
        /// </summary>
        public class TransException : System.Exception
        {
            private string cmdDetail;
            public string CommandDetail
            {
                get { return this.cmdDetail; }
            }
            private Exception srcException;
            public Exception SourceException
            {
                get { return this.srcException; }
            }
            public TransException(string cmdDetail, Exception srcException)
            {
                this.srcException = srcException;
                this.cmdDetail = cmdDetail;
            }
        }
        #endregion
       
        private bool doesThrowTransException;
        /// <summary>
        /// 
        /// </summary>
        public bool DoesThrowTransException
        {
            get { return doesThrowTransException; }
            set { doesThrowTransException = value; }
        }


        #region Connection
        private System.Data.Common.DbConnection transConn;
        /// <summary>
        /// 
        /// </summary>
        public System.Data.Common.DbConnection Connection
        {
            get { return transConn; }
            set
            {
                transConn = value;
                this.connString = transConn.ConnectionString;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool IsConnectionOpen
        {
            get {
                if (this.transConn != null && this.transConn.State == System.Data.ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private System.Data.Common.DbTransaction trans;
        /// <summary>
        /// 
        /// </summary>
        public System.Data.Common.DbTransaction Transaction
        {
            get { return this.trans; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="conn"></param>
        public Db(System.Data.Common.DbConnection conn)
        {
            this.factory = this.GetFactoryByConfig(Framework.Config.DbProvider);
            if (conn != null)
            {
                this.Connection = conn;
            }
            else
            {
                System.Data.Common.DbConnection con = this.factory.CreateConnection();
                con.ConnectionString = Db.commonConnString;
                this.Connection = con;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="dbProvider"></param>
        public Db(System.Data.Common.DbConnection conn, string dbProvider)
        {
            this.factory = this.GetFactoryByConfig(dbProvider);
            if (conn != null)
            {
                this.Connection = conn;
            }
            else
            {
                System.Data.Common.DbConnection con = this.factory.CreateConnection();
                con.ConnectionString = Db.commonConnString;
                this.Connection = con;
            }
        }
        #endregion

        #region Trans Command
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbCommand CreateTransCommand(string commandText)
        {
            if (!this.IsConnectionOpen || this.trans == null)
            {
                return this.CreateCommand(commandText);
            }
            DbCommand cmd = this.transConn.CreateCommand();
            if (!commandText.IsNullOrEmpty())
            {
                cmd.CommandText = commandText;
            }
            if (this.trans.Connection != null)
            {
                cmd.Transaction = this.trans;
            }
            return cmd;
        }
        #endregion
        #region Trans
        #region BeginTransaction Commit Rollback
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool TransBegin()
        {
            try
            {
                if (this.transConn == null)
                {
                    this.transConn = this.factory.CreateConnection();
                    this.transConn.ConnectionString = this.connString;
                }
                this.transConn.Open();
                this.trans = this.transConn.BeginTransaction();
                return true;
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(e2);
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <returns></returns>
        public bool TransBegin(System.Data.IsolationLevel isolationLevel)
        {
            try
            {
                if (this.transConn == null)
                {
                    this.transConn = this.factory.CreateConnection();
                    this.transConn.ConnectionString = this.connString;
                }
                this.transConn.Open();
                this.trans = this.transConn.BeginTransaction(isolationLevel);
                return true;
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(e2);
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool TransCommit()
        {
            try
            {
                this.trans.Commit();
                return true;
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(e2);
            }
            catch (System.Exception ex)
            {
                Framework.ExceptionHandler.Handle(ex);
            }
            finally
            {
                if (this.IsConnectionOpen)
                {
                    try
                    {
                        this.transConn.Close();
                    }
                    catch (InvalidOperationException e1)
                    {
                        Framework.ExceptionHandler.Handle(e1);
                    }
                    catch (Exception ex)
                    {
                        Framework.ExceptionHandler.Handle(ex);
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool TransRollback()
        {
            if ( ! this.IsConnectionOpen)
            {
                return false;
            }
            try
            {
                this.trans.Rollback();
                return true;
            }
            catch (InvalidOperationException e1)
            {
                Framework.ExceptionHandler.Handle(e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                Framework.ExceptionHandler.Handle(e2);
            }
            catch (System.Exception ex)
            {
                Framework.ExceptionHandler.Handle(ex);
            }
            finally
            {
                try
                {
                    this.transConn.Close();
                }
                catch (InvalidOperationException e1)
                {
                    Framework.ExceptionHandler.Handle(e1);
                }
                catch (Exception ex)
                {
                    Framework.ExceptionHandler.Handle(ex);
                }
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cmdDetail"></param>
        /// <param name="ex"></param>
        public void TransRollback( string cmdDetail , Exception ex)
        {
            this.TransRollback();
            Framework.ExceptionHandler.Handle(cmdDetail , ex);
            if (this.doesThrowTransException)
            {
                throw new TransException(cmdDetail, ex);
            }
        }
        #endregion

        #region DataTable
        #region ExecuteScalar
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public object TransExecuteScalar(System.Data.Common.DbCommand selectCommand)
        {
            if ( ! this.IsConnectionOpen)
            {
                return null;
            }

            object rst = null;
            try
            {
                selectCommand.CommandTimeout = 0;
                rst = selectCommand.ExecuteScalar();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(selectCommand.CommandText, e2);
            }
            return rst;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public object TransExecuteScalar(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateTransCommand(selectCommandText))
            {
                return this.TransExecuteScalar(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public bool TransDoesDataExist(string selectCommandText)
        {
            return this.TransExecuteScalar(selectCommandText) != null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public bool TransDoesDataExist(System.Data.Common.DbCommand selectCommand)
        {
            return this.TransExecuteScalar(selectCommand) != null;
        }
        #endregion

        #region GetDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.DataTable TransGetDataTable(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateTransCommand(selectCommandText))
            {
                return this.TransGetDataTable(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.DataTable TransGetDataTable(System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Data.DataTable();
            }

            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                this.TransRollback(selectCommand.CommandText, e);
            }
            return table == null ? new System.Data.DataTable() : table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> TransGetValueText(string selectCommandText)
        {
            using (DbCommand selectCommand = this.CreateTransCommand(selectCommandText))
            {
                return this.TransGetValueText(selectCommand);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Collections.Generic.List<Framework.ValueText> TransGetValueText(System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Collections.Generic.List<Framework.ValueText>();
            }

            System.Collections.Generic.List<Framework.ValueText> list = new System.Collections.Generic.List<Framework.ValueText>();
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    list.Add(new Framework.ValueText(reader.GetValue(0).ToString(), reader.GetValue(1).ToString()));
                }
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                this.TransRollback(selectCommand.CommandText, e);
            }
            return list;
        }

        #endregion

        #region AppendToDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        public void TransAppendToDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand)
        {
            if (!this.IsConnectionOpen)
            {
                return ;
            }

            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                this.TransRollback(selectCommand.CommandText, e);
            }
        }
        #endregion
        #region SynchronizeDataTable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="selectCommand"></param>
        /// <param name="primaryKeyName"></param>
        /// <param name="importedCount"></param>
        /// <param name="refreshedCount"></param>
        public void TransSynchronizeDataTable(System.Data.DataTable table, System.Data.Common.DbCommand selectCommand, string[] primaryKeyName, ref int importedCount, ref int refreshedCount)
        {
            if (!this.IsConnectionOpen)
            {
                return ;
            }

           // retrieve configuration from database
            try
            {
                selectCommand.CommandTimeout = 0;
                System.Data.Common.DbDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                while (reader.Read())
                {
                    bool canAdd = true;
                    System.Data.DataRow foundRow = null;
                    if (primaryKeyName != null)
                    {
                        object[] keys = new object[primaryKeyName.Length];
                        for (int i = 0; i < primaryKeyName.Length; i++)
                        {
                            keys[i] = reader.GetValue(i);
                        }

                        foundRow = table.Rows.Find(keys);
                        if (foundRow != null)
                        {
                            canAdd = false;
                        }
                    }
                    if (canAdd)
                    {
                        System.Data.DataRow row = table.NewRow();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }
                        table.Rows.Add(row);
                        importedCount++;
                    }
                    else
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            foundRow[i] = reader.GetValue(i);
                        }
                        refreshedCount++;
                    }
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(selectCommand.CommandText, e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(selectCommand.CommandText, e2);
            }
            catch (Exception e)
            {
                this.TransRollback(selectCommand.CommandText, e);
            }
        }
        #endregion
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int TransExecuteNonQuery(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return -1;
            }

            try
            {
                command.CommandTimeout = 0;
                return command.ExecuteNonQuery();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(this.GetCommandDetail(command), e2);
            }
            return -1;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public int TransExecuteNonQuery(string commandText)
        {
            using (DbCommand command = this.CreateTransCommand(commandText))
            {
                return this.TransExecuteNonQuery(command);
            }
        }
        #endregion

        #region ExecuteProcedure
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public int TransExecuteProcedure(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }
            int result = -1;
            System.Data.Common.DbParameter parameter = null;
            try
            {
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;
                parameter = this.AppendReturnParameter(command, "@Return");
                command.ExecuteNonQuery();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(this.GetCommandDetail(command), e2);
            }
            finally
            {
                result = (int)parameter.Value;
            }
            return result;
        }
        #endregion

        #region ExecuteProcedure
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public System.Data.DataTable TransExecuteProcedureForDataTable(System.Data.Common.DbCommand command)
        {
            if (!this.IsConnectionOpen)
            {
                return new System.Data.DataTable();
            }

            System.Data.DataTable table = new System.Data.DataTable();
            try
            {
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandTimeout = 0;

                System.Data.Common.DbDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.SingleResult);
                // build table structure
                if (table.Columns.Count == 0)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                }
                
                while (reader.Read())
                {
                    // append a new row to this table
                    System.Data.DataRow row = table.NewRow();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[i] = reader.GetValue(i);
                    }
                    table.Rows.Add(row);
                }
                table.AcceptChanges();
                reader.Close();
            }
            catch (InvalidOperationException e1)
            {
                this.TransRollback(this.GetCommandDetail(command), e1);
            }
            catch (System.Data.Common.DbException e2)
            {
                this.TransRollback(this.GetCommandDetail(command), e2);
            }
            catch (Exception e)
            {
                this.TransRollback(this.GetCommandDetail(command), e);
            }
            return table;
        }
        #endregion

        #region DbDataAdapter
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommandText"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter TransCreateDataAdapter(string selectCommandText)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = this.CreateTransCommand(selectCommandText);
            return adapter;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public System.Data.Common.DbDataAdapter TransCreateDataAdapter(System.Data.Common.DbCommand selectCommand)
        {
            System.Data.Common.DbDataAdapter adapter = this.factory.CreateDataAdapter();
            adapter.SelectCommand = selectCommand;
            return adapter;
        }

        #region DbDataAdapter.Fill()
        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int TransDbDataAdapterFill(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(dt);
            }
            catch (InvalidOperationException ioe)
            {
                this.TransRollback(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                this.TransRollback(this.GetCommandDetail(adapter.SelectCommand), dbe);
            }
            catch (NullReferenceException nre)
            {
                this.TransRollback(string.Empty,nre);
            }
            catch (ArgumentNullException nulle)
            {
                this.TransRollback(string.Empty,nulle);
            }
            catch (SystemException syse)
            {
                this.TransRollback(string.Empty,syse);
            }
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int TransDbDataAdapterFill(string connectionString, System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                result = adapter.Fill(ds);
            }
            catch (InvalidOperationException ioe)
            {
                Framework.ExceptionHandler.Handle(ioe);
                this.TransRollback(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                this.TransRollback(this.GetCommandDetail(adapter.SelectCommand), dbe);
            }
            catch (NullReferenceException nre)
            {
                this.TransRollback(string.Empty,nre);
            }
            catch (ArgumentNullException nulle)
            {
                this.TransRollback(string.Empty,nulle);
            }
            catch (SystemException syse)
            {
                this.TransRollback(string.Empty,syse);
            }
            return result;
        }
        #endregion

        #region DbDataAdapter.Update()
        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int TransDbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataTable dt)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = this.transConn;
                    adapter.UpdateCommand.Transaction = this.trans;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = this.transConn;
                    adapter.InsertCommand.Transaction = this.trans;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = this.transConn;
                    adapter.DeleteCommand.Transaction = this.trans;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                result = adapter.Update(dt);
            }
            catch (InvalidOperationException ioe)
            {
                this.TransRollback(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                string cmdDetail = this.GetCommandDetail(adapter.SelectCommand);
                if (adapter.UpdateCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "UpdateCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.UpdateCommand);
                }
                if (adapter.InsertCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "InsertCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.InsertCommand);
                }
                if (adapter.DeleteCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "DeleteCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.DeleteCommand);
                }
                this.TransRollback(cmdDetail, dbe);
            }
            catch (ArgumentNullException nulle)
            {
                this.TransRollback(string.Empty,nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                this.TransRollback(string.Empty,dbe);
            }
            catch (SystemException syse)
            {
                this.TransRollback(string.Empty,syse);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="ds"></param>
        /// <returns></returns>
        public int TransDbDataAdapterUpdate(System.Data.Common.DbDataAdapter adapter, System.Data.DataSet ds)
        {
            if (!this.IsConnectionOpen)
            {
                return -2;
            }

            int result = -1;
            try
            {
                adapter.SelectCommand.CommandTimeout = 0;
                if (adapter.UpdateCommand != null)
                {
                    adapter.UpdateCommand.Connection = this.transConn;
                    adapter.UpdateCommand.Transaction = this.trans;
                    adapter.UpdateCommand.CommandTimeout = 0;
                }
                if (adapter.InsertCommand != null)
                {
                    adapter.InsertCommand.Connection = this.transConn;
                    adapter.InsertCommand.Transaction = this.trans;
                    adapter.InsertCommand.CommandTimeout = 0;
                }
                if (adapter.DeleteCommand != null)
                {
                    adapter.DeleteCommand.Connection = this.transConn;
                    adapter.DeleteCommand.Transaction = this.trans;
                    adapter.DeleteCommand.CommandTimeout = 0;
                }
                result = adapter.Update(ds);
            }
            catch (InvalidOperationException ioe)
            {
                this.TransRollback(string.Empty,ioe);
            }
            catch (System.Data.Common.DbException dbe)
            {
                string cmdDetail = this.GetCommandDetail(adapter.SelectCommand);
                if (adapter.UpdateCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "UpdateCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.UpdateCommand);
                }
                if (adapter.InsertCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "InsertCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.InsertCommand);
                }
                if (adapter.DeleteCommand != null)
                {
                    cmdDetail += System.Environment.NewLine + "DeleteCommand£º" + System.Environment.NewLine + this.GetCommandDetail(adapter.DeleteCommand);
                }
                this.TransRollback(cmdDetail, dbe);
            }
            catch (ArgumentNullException nulle)
            {
                this.TransRollback(string.Empty,nulle);
            }
            catch (System.Data.DBConcurrencyException dbe)
            {
                this.TransRollback(string.Empty,dbe);
            }
            catch (SystemException syse)
            {
                this.TransRollback(string.Empty,syse);
            }
            return result;
        }
        #endregion
        #endregion
        #endregion
    }
}
