﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.OleDb;
using System.Data.Common;
using Sunpire.Framework;

namespace Sunpire.DA
{
    /*
      Extended Properties='Excel 8.0;HDR=yes;IMEX=1'

      A:  HDR ( HeaDer Row )
     'Yes' stands for the first row contains column names in the spreadsheet
     'No' stands for the first row contains data in the spreadsheet, there are no column names specified

     B: IMEX ( IMport EXport mode )
      0 is Export mode, Write only.
      1 is Import mode, Read only.
      2 is Linked mode (full update capabilities), Read and Write
      */
    /// <summary>
    /// 
    /// </summary>
    public class ExcelDbAccessor
    {
        #region enum
        /// <summary>
        /// IMEX ( IMport EXport mode )
        /// 0 is Export mode, Write only.
        /// 1 is Import mode, Read only.
        /// 2 is Linked mode (full update capabilities), Read and Write
        /// </summary>
        public enum IMEXModes
        {
            /// <summary>
            /// Read only
            /// </summary>
            Import = 1,
            /// <summary>
            /// Write only
            /// </summary>
            Export = 0,
            /// <summary>
            /// Read and Write
            /// </summary>
            Linked = 2
        }
        #endregion

        Db dbField;
        Db db
        {
            get
            {
                if (this.dbField == null)
                {
                    this.dbField = new Db(this.BuildConnectionString(), "OleDb");
                }
                return this.dbField;
            }
        }
        /// <summary>
        /// IncludeHeaderRow = false ,  Mode = IMEXModes.Import
        /// </summary>
        public ExcelDbAccessor()
            : this(false, IMEXModes.Import)
        {
        }
        /// <summary>
        /// IncludeHeaderRow = false ,  Mode = IMEXModes.Import
        /// </summary>
        /// <param name="filepath"></param>
        public ExcelDbAccessor(string filepath)
            : this(false, IMEXModes.Import, filepath, false)
        {
        }
        /// <summary>
        /// File path is not specified
        /// </summary>
        /// <param name="includeHeaderRow">HDR</param>
        /// <param name="mode">IMEX</param>
        public ExcelDbAccessor(bool includeHeaderRow, IMEXModes mode)
            : this(includeHeaderRow, mode, string.Empty, false)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includeHeaderRow">HDR</param>
        /// <param name="mode">IMEX</param>
        /// <param name="filepath"></param>
        public ExcelDbAccessor(bool includeHeaderRow, IMEXModes mode, string filepath, bool isText)
        {
            this.IncludeHeaderRow = includeHeaderRow;
            this.Mode = mode;
            this.FilePath = filepath;
            this.IsText = isText;
        }

        #region properties
        /// <summary>
        /// Is CSV or Excel
        /// </summary>
        public bool IsText
        {
            get;
            private set;
        }

        /// <summary>
        /// Excel FilePath
        /// </summary>
        public string FilePath
        {
            get;
            set;
        }

        /// <summary>
        /// CSV File Directory
        /// </summary>
        public string FileDirectory
        {
            get { return System.IO.Path.GetDirectoryName(this.FilePath); }
        }

        /// <summary>
        /// CSV Filename
        /// </summary>
        public string FileName
        {
            get { return System.IO.Path.GetFileName(this.FilePath); }
        }

        /// <summary>
        /// CSV Delimiter
        /// </summary>
        public string Delimiter
        {
            get;
            set;
        }


        string[] sheetNames;
        /// <summary>
        /// Spreadsheets in Excel
        /// </summary>
        public string[] SheetNames
        {
            get
            {
                if (this.sheetNames == null)
                {
                    this.GetSheetNames();
                }
                return this.sheetNames;
            }
        }
        /// <summary>
        /// HDR property specified in the connection string
        /// </summary>
        public bool IncludeHeaderRow { get; set; }
        /// <summary>
        /// IMEX property specified in the connection string
        /// </summary>
        public IMEXModes Mode { get; set; }
        ///// <summary>
        ///// Keep Connection Open
        ///// </summary>
        //public bool KeepConnectionOpen { get; set; }
        #endregion

        #region Excel Connection
        private string BuildConnectionString()
        {
            if (this.IsText)
            {
                return string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Text;HDR={1};IMEX={2};Delimited({3})'",
                    this.FileDirectory, this.IncludeHeaderRow ? "Yes" : "No", (byte)this.Mode, this.Delimiter);
            }
            else
            {
                //return string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1};IMEX={2}'",
                //    this.FilePath, this.IncludeHeaderRow ? "Yes" : "No", (byte)this.Mode);
                return string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0;HDR={1};IMEX={2}'",
                    this.FilePath, this.IncludeHeaderRow ? "YES" : "NO", (byte)this.Mode);
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get SheetNames
        /// </summary>
        public void GetSheetNames()
        {
            System.Data.DataTable dt = db.GetSchema("Tables");
            this.sheetNames = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string name = dt.Rows[i]["TABLE_NAME"].ToString();
                // If SheetName is numeric, the SheetName will be around with "'"
                if (name[0] == '\'' && name[name.Length - 1] == '\'')
                {
                    this.sheetNames[i] = name.Substring(1, name.Length - 3);
                }
                else
                {
                    this.sheetNames[i] = name.Substring(0, name.Length - 1);
                }
            }
        }
        /// <summary>
        /// Get the content from range
        /// </summary>
        /// <param name="sheetName"></param>
        /// <param name="range">string.Empty stands for all cells, 'A1' stands a single cell, 'A1:B2' stands for a range for cells</param>
        /// <param name="fieldIndexList">Uses a comma as delimiter.
        /// string.Empty stands for all columns, otherwise, according to the value of IncludeHeaderRow to read columns: 
        ///  when IncludeHeaderRow = true, fieldIndexList should be composited with column names,
        ///  otherwise, it should be composited with indexes, such as "0,1,2,3,4,5..."</param>
        /// <returns></returns>
        public System.Data.DataTable GetRangeValue(string sheetName, string range, string fieldIndexList)
        {
            return db.GetDataTable(this.BuildSelectCommandText(sheetName, range, fieldIndexList));
        }
        /// <summary>
        /// Get the content of a single cell
        /// </summary>
        /// <param name="sheetName"></param>
        /// <param name="cell"></param>
        /// <returns></returns>
        public object GetCellValue(string sheetName, string cell)
        {
            return db.ExecuteScalar(this.BuildSelectCommandText(sheetName, cell, string.Empty));
        }

        public int ExecuteNonQuery(string commandText)
        {
            return db.ExecuteNonQuery(commandText);
        }
        #endregion

        #region Supporting
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sheetName"></param>
        /// <param name="range">string.Empty stands for all cells, 'A1' stands a single cell, 'A1:B2' stands for a range for cells</param>
        /// <param name="fieldIndexList">Uses a comma as delimiter.
        /// string.Empty stands for all columns, otherwise, according to the value of IncludeHeaderRow to read columns: 
        ///  when IncludeHeaderRow = true, fieldIndexList should be composited with column names,
        ///  otherwise, it should be composited with indexes, such as "0,1,2,3,4,5..."</param>
        /// <returns></returns>
        string BuildSelectCommandText(string sheetName, string range, string fieldIndexList)
        {
            string fieldList;
            if (fieldIndexList.IsNullOrEmpty())
            {
                fieldList = "*";
            }
            else
            {
                if (this.IncludeHeaderRow)
                {
                    fieldList = "[" + fieldIndexList.Replace(",", "],[") + "]";
                }
                else
                {
                    fieldList = "F" + fieldIndexList.Replace(",", ",F");  //string.Join(",F", fieldIndexList.Split(','));
                }
            }
            if (range.Trim() == string.Empty || range.IndexOf(":") >= 2)
            {
                if (!this.IsText)
                {
                    return string.Format("Select {0} From [{1}${2}]", fieldList, sheetName, range.Trim());
                }
                else
                {
                    return string.Format("Select {0} From [{1}]", fieldList, sheetName);
                }
            }
            else
            {
                return string.Format("Select * From [{0}${1}:{2}]", sheetName, range.Trim(), range.Trim());
            }
        }



        /// <summary>
        /// Extract the row index and the column index from the given cell name.
        /// Notes: Row index/column starts from 1
        /// </summary>
        /// <param name="cell">in the format as 'AB12' or 'AB'</param>
        /// <returns></returns>
        public static int[] ToNumbers(string cell)
        {
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(cell, @"(?<Col>[A-Za-z]+)(?<Row>[0-9]*)", System.Text.RegularExpressions.RegexOptions.Compiled);
            if (m.Success)
            {
                int[] rst = new int[2];
                if (m.Groups["Col"].Value.IsNullOrEmpty())
                {
                    rst[0] = 0;
                }
                else
                {
                    rst[0] = FromAlphabetic(m.Groups["Col"].Value);
                }
                if (m.Groups["Row"].Value.IsNullOrEmpty())
                {
                    rst[1] = 0;
                }
                else
                {
                    rst[1] = int.Parse(m.Groups["Row"].Value);
                }
                return rst;
            }
            else
            {
                return new int[] { 0, 0 };
            }
        }
        #endregion
        /// <summary>
        /// Converts a column name to index. 
        /// It is on the opposite side for ToAlphabetic().
        /// </summary>
        /// <param name="colName"></param>
        /// <returns></returns>
        public static int FromAlphabetic(string colName)
        {
            colName = colName.ToUpper();
            int colIndex = 0;
            if (colName.Length == 1)
            {
                colIndex = Convert.ToInt16(Convert.ToByte(colName[0]) - 65);
            }
            else if (colName.Length == 2)
            {
                colIndex = Convert.ToInt16(Convert.ToByte(colName[1]) - 65);
                colIndex += Convert.ToInt16(Convert.ToByte(colName[0]) - 64) * 26;
            }
            else if (colName.Length == 3)
            {
                colIndex = Convert.ToInt16(Convert.ToByte(colName[2]) - 65);
                colIndex += Convert.ToInt16(Convert.ToByte(colName[1]) - 64) * 26;
                colIndex += Convert.ToInt16(Convert.ToByte(colName[0]) - 64) * 676;
            }
            return colIndex + 1;
        }
    }
}
