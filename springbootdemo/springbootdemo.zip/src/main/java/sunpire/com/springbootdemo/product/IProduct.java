package sunpire.com.springbootdemo.product;

public interface IProduct {
	
	public String getModelNo();
}

